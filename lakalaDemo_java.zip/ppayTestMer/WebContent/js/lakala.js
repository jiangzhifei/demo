/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2015-01-20 11:45:12
 * @version $Id$
 */
$(function(){
           
            $("input").attr('data-role','none');  
            $("select").attr('data-role','none');
            $('#lak-head em img').click(function(){
                $('.barto').show();
                $('.barto span').click(function(){
                $('.barto').hide();  
                });
            });
            $('.xieyi span a').click(function(){
                $('.xieyii').show();
                $('.xieyii span').click(function(){
                $('.xieyii').hide();  
                });
            });

            var such = document.documentElement.clientHeight || document.body.clientHeight;
            var teaxh = 0.44*such;  
            var lahet = $('.lak-send').height();
            $('.lak_sendcont textarea').css("height",teaxh);
            $('.lak-send').offset({bootom:-lahet,left:0});
            $('.lak-boot em').click(function(){
            $('.lak-send').animate({bottom:0},1000).show();
            $('.ls-yicang').click(function(){
            $('.lak-send').animate({bottom:-lahet},1000,function(){
            $('.lak-send').hide()});
                });
            });

            var laynh = $('.la-xinka').height();
            $('.la-xinka').css("height",teaxh);
            $('.la-xinka').offset({bootom:-laynh,left:0});
            $('.chakayh a').click(function(){
            $('.la-xinka').animate({bottom:0},1000).show();
            });
            $('.la-xinka table .lastoff').click(function(){
            $('.la-xinka').animate({bottom:-laynh},1000,function(){ $('.la-xinka').hide()});
            });


            /* 首页借记卡 信用卡替换的jq*/

            var inhe = $('.la-xuanzeb').height();
            var inh = 0.3*such;
             $('.la-xuanzeb a').css("height",inh);
            $('.la-xuanzeb').offset({bootom:-inhe,left:0})
            $('.la-zf .jjcheck').click(function(){
                $('.la-xuanzeb').animate({bottom:0},1000).show();
            });
                // event.stopPropagation();
                 
                $('.la-xuanze a').children('span').click(function(){
                     var text = $('.la-xuanze span').eq($(this).index()).text();
                                       
                     if(text=="借记卡")
                        {
                            $('.labig').css("font-size","1.4em");
                            $('.xibig').css("font-size","1em");
                            $('.la-zf .jjcheck i').text(text);
                            $('.xinyongk').hide();
                            $('.la-xuanzeb').hide();
                        }
                    else
                    {
                        $('.xibig').css("font-size","1.4em");
                        $('.labig').css("font-size","1em");
                        $('.la-zf .jjcheck i').text(text);
                        $('.xinyongk').show();
                        $('.la-xuanzeb').hide();
                    }

                });

            $('.la-xuanzeb P').click(function(){
                $('.la-xuanzeb').animate({bottom:-inhe},1000,function(){ 
                    $('.la-xuanzeb').hide()});
            });
                
          //     $('.la-zf .jjcheck').click(function(){
          //    $('.la-xuanze').animate({margin-top: -inhe}, 1000,function(){
          //       $('.la-xuanzeb').hide();
          //       // $('.la-xuanze').css("margin-top",'0');
          //    });
              
          // });
        })


          // var such = document.documentElement.clientHeight || document.body.clientHeight;
            // var teaxh = 0.38*such;
            // $('.lak_sendcont textarea').css("height",teaxh)
            // $('.lak-send').css("height",such);
            // $('.lak-send').offset({top:such,left:0});
            // $('.lak-boot em').click(function(){
            // $('.lak-send').animate({top:0},1000).show();
            // });
            // $('.ls-yicang').click(function(){
            // $('.lak-send').animate({top:such},1000,function(){
            //     $('.lak-send').hide()});
            // });  