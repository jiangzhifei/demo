package com.lakala.testmer.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class PropertiesConfigUtil {

	public static Properties load(String fileName) {
		Properties prop = new Properties();
		String msg = "";
		try {
			InputStream fis = new FileInputStream(fileName);
			//从输入流中读取属性列表（键和元素对）
			prop.load(fis);
			fis.close();
		} catch (IOException e) {
			System.err.println("Visit "+fileName+" for "+msg);
		}
		return prop;
	}
	
	public static void save(String fileName, Properties prop) {
		try {
			OutputStream fos = new FileOutputStream(fileName);
			//以适合使用 load 方法加载到 Properties 表中的格式，
			//将此 Properties 表中的属性列表（键和元素对）写入输出流
			prop.store(fos, "");
			fos.flush();
			fos.close();
		} catch (IOException e) {
			System.err.println("Visit "+fileName+" exception.");
		}
	}
	
	public static void main(String args[]) {
		Properties prop = new Properties();
		prop.setProperty("key1", "value1");
		prop.setProperty("key2", "http://www.ytbpay.cn:8080/ppayTestMer/result.jsp");
		save("a.properties",prop);
		
		Properties prop1 = load("a.properties");
		System.out.println(prop1);
		
		System.out.println("key2="+prop1.getProperty("key2"));
	}
}
