package com.lakala.testmer.util;

public class SeqUtil {

	private static int n=0;
	public static int getSeq() {
		return n++;
	}
	
}
