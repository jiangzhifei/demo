package com.lakala.testmer.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
/**
 * 预付费支付接口
 * @author 马海
 *
 */
public class RemainPayMsg {
	private String transactionid;
	private String taccountid;
	private String spid;
	private String pid;
	private String orderamount;
	private String ordertime;
	private String productname;
	private String producttype;
	private String ext1;
	private String ext2;
	private String signmsg;
	
	/**
	 * 从商户提交订单MAP对象中获取各个参数对应的值
	 * @param paramMap
	 * @param name
	 * @return
	 */
	static private String getValue(Map paramMap,String name){
		Object o   = paramMap.get(name);
		if(o==null)
			return null;
		if(!o.getClass().isArray()){
			return o.toString();
		}else{
	 		return ((Object[])o)[0].toString();
		}

	}
	
	/**
	 * 构造分账付款信息
	 * @param paramMap
	 * @return
	 */
	static public RemainPayMsg getSharingPayMsg(Map paramMap){
		RemainPayMsg sharingPayMsg = new RemainPayMsg();
		sharingPayMsg.setTransactionid(getValue(paramMap,"transactionid"));
		sharingPayMsg.setTaccountid(getValue(paramMap,"taccountid"));
		sharingPayMsg.setPid(getValue(paramMap,"pid"));
		sharingPayMsg.setSpid(getValue(paramMap,"spid"));
		sharingPayMsg.setOrderamount(getValue(paramMap,"orderamount"));
		sharingPayMsg.setOrdertime(getValue(paramMap,"ordertime"));
		sharingPayMsg.setProductname(getValue(paramMap,"productname"));
		sharingPayMsg.setProducttype(getValue(paramMap,"producttype"));
		sharingPayMsg.setExt1(getValue(paramMap,"ext1"));
		sharingPayMsg.setExt2(getValue(paramMap,"ext2"));
		sharingPayMsg.setSignmsg(getValue(paramMap,"signmsg"));
		return sharingPayMsg;
	}
	
	/**
	 * 构造签名串
	 * @param sharingPayMsg
	 * @return
	 */
	public String getSharingPayStr(){
		StringBuffer sharingDataStr = new StringBuffer();
		
		if(getTransactionid()!=null){
			sharingDataStr.append("transactionid="+getTransactionid()+"&");
		}
		if(getOrderamount()!=null){
			sharingDataStr.append("orderamount="+getOrderamount()+"&");
		}
		if(getOrdertime()!=null){
			sharingDataStr.append("ordertime="+getOrdertime()+"&");
		}
		if(getPid()!=null){
			sharingDataStr.append("pid="+getPid()+"&");
		}
		if(getTaccountid()!=null){
			sharingDataStr.append("taccountid="+getTaccountid()+"&");
		}
		if(getProducttype()!=null){
			sharingDataStr.append("producttype="+getProducttype()+"&");
		}
		if(getSpid()!=null){
			sharingDataStr.append("spid="+getSpid()+"&");
		}
		if(!sharingDataStr.toString().equals("")){
			sharingDataStr.deleteCharAt(sharingDataStr.lastIndexOf("&"));
		}
		return sharingDataStr.toString();
	}

	/**
	 * 构造webService提交串
	 * @param sharingPayMsg
	 * @return transactionid=&pid=&taccountid=&orderamount=&ordertime=&productname=&producttype=&ext1=&ext2=
	 */
	public String getPayStr(){
		StringBuffer sharingDataStr = new StringBuffer();
		if(getTransactionid()!=null){
			sharingDataStr.append("transactionid="+getTransactionid()+"&");
		}
		if(getPid()!=null){
			sharingDataStr.append("pid="+getPid()+"&");
		}
		if(getTaccountid()!=null){
			sharingDataStr.append("taccountid="+getTaccountid()+"&");
		}
		if(getOrderamount()!=null){
			sharingDataStr.append("orderamount="+getOrderamount()+"&");
		}
		if(getOrdertime()!=null){
			sharingDataStr.append("ordertime="+getOrdertime()+"&");
		}
		if(getProductname()!=null){
			sharingDataStr.append("productname="+getProductname()+"&");
		}
		if(getProducttype()!=null){
			sharingDataStr.append("producttype="+getProducttype()+"&");
		}
		if(getExt1()!=null){
			sharingDataStr.append("ext1="+getExt1()+"&");
		}
		if(getExt2()!=null){
			sharingDataStr.append("ext2="+getExt2()+"&");
		}
		if(getSpid()!=null){
			sharingDataStr.append("spid="+getSpid()+"&");
		}
		if(!sharingDataStr.toString().equals("")){
			sharingDataStr.deleteCharAt(sharingDataStr.lastIndexOf("&"));
		}
		return sharingDataStr.toString();
	}
	public String getTransactionid() {
		return transactionid;
	}

	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}

	public String getTaccountid() {
		return taccountid;
	}

	public void setTaccountid(String taccountid) {
		this.taccountid = taccountid;
	}

	public String getOrderamount() {
		return orderamount;
	}

	public void setOrderamount(String orderamount) {
		this.orderamount = orderamount;
	}

	public String getOrdertime() {
		return ordertime;
	}

	public void setOrdertime(String ordertime) {
		this.ordertime = ordertime;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getExt1() {
		return ext1;
	}

	public void setExt1(String ext1) {
		this.ext1 = ext1;
	}

	public String getExt2() {
		return ext2;
	}

	public void setExt2(String ext2) {
		this.ext2 = ext2;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getSignmsg() {
		return signmsg;
	}

	public void setSignmsg(String signmsg) {
		this.signmsg = signmsg;
	}

	public String getProducttype() {
		return producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	public String getSpid() {
		return spid;
	}

	public void setSpid(String spid) {
		this.spid = spid;
	}
	
}
