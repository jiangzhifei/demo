package com.lakala.testmer.util;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.Security;

public class PayEncrypt {
private  final String Algorithm = "DESede"; //定义 加密算法,可用 DES,DESede,Blowfish
	private void PayEncrypt(){
		//添加新安全算法,如果用JCE就要把它添加进去
        Security.addProvider(new com.sun.crypto.provider.SunJCE());
	}

    public  String encryptMode(String key,String src)throws EncException{
    	try {
			byte[] destbyte=encryptMode(key.getBytes("utf-8"), src.getBytes("utf-8"));
			BASE64Encoder base64en = new BASE64Encoder();
			String base64Str = base64en.encode(destbyte);
			base64Str = base64Str.replaceAll("\\r|\\n", "");
			return base64Str;
		} catch (Exception e) {
			throw new EncException(1,"PayEncrypt","encryptMode","加密错误",null);
		}
		
    }
    
  //解密方法  参数:key解密密钥、  src需要进行解密的串
    public  String decryptMode(String key,String src)throws EncException{
    	src=src.replace(" ", "+");  //解密处理   get方法 替换字符处理(get方法时 会将空格(" ") 替换成"+" )
    	try {
            ;
			byte[] srcbyte=Base64.decodeBase64(src);
			byte[] destbyte=decryptMode(key.getBytes("utf-8"), srcbyte);
			return new String(destbyte);
		} catch (Exception e) {
			throw new EncException(1,"PayEncrypt","encryptMode","解密错误",null);
		}
    }
    //keybyte为加密密钥，长度为24字节
    //src为被加密的数据缓冲区（源）
    public  byte[] encryptMode(byte[] keybyte, byte[] src) {
       try {
            //生成密钥
            SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);

            //加密
            Cipher c1 = Cipher.getInstance(Algorithm);
            c1.init(Cipher.ENCRYPT_MODE, deskey);
            return c1.doFinal(src);
        } catch (java.security.NoSuchAlgorithmException e1) {
        } catch (javax.crypto.NoSuchPaddingException e2) {
        } catch (java.lang.Exception e3) {
        }
        return null;
    }

    //keybyte为加密密钥，长度为24字节
    //src为加密后的缓冲区
    public  byte[] decryptMode(byte[] keybyte, byte[] src) {      
	try {
            //生成密钥
            SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);

            //解密
            Cipher c1 = Cipher.getInstance(Algorithm);
            c1.init(Cipher.DECRYPT_MODE, deskey);
            return c1.doFinal(src);
        } catch (java.security.NoSuchAlgorithmException e1) {
        } catch (javax.crypto.NoSuchPaddingException e2) {
        } catch (java.lang.Exception e3) {
        }
        return null;
    }

    //转换成十六进制字符串
    public  String byte2hex(byte[] b) {
        String hs="";
        String stmp="";

        for (int n=0;n<b.length;n++) {
            stmp=(java.lang.Integer.toHexString(b[n] & 0XFF));
            if (stmp.length()==1) hs=hs+"0"+stmp;
            else hs=hs+stmp;
            if (n<b.length-1)  hs=hs+":";
        }
        return hs.toUpperCase();
    }
    
    public static void main(String args[]) throws EncException {
    	PayEncrypt pe = new PayEncrypt();
    	String kekStr = "GheuVsd21ppay5J52DwfjTay"; // 平台KEK
    	
    	String minKey = "1234567890123456asdfas12";
    	String encMerKey = pe.encryptMode(kekStr, minKey); //经平台加密得到密文key
    	System.out.println("商户密钥密文="+encMerKey);
    	
    	encMerKey = "sI5778ZTPdNZ+u+aDYYChIJQKQJDnpsd4ni0anHORmo=";
    	minKey = pe.decryptMode(kekStr, encMerKey); //经平台解密得到明文key
    	System.out.println("商户密钥明文="+minKey);
    	
    	String merKey = "LDPGJLDE14GUQPW0XM6WY4CJ";
    	String sharingDataStr = "1^105290054110500^50.00^0^0.50^desc|1^105290054110501^50.00^0^0.50^desc";
    	String encSharingDataStr = pe.encryptMode(merKey, sharingDataStr);
    	System.out.println("分账加密密文:"+encSharingDataStr);
    	
    	encSharingDataStr = "CxUpddZ4/d0KFCVCKInlkgGS5znYkMAsUIXe5A9FtAcGSrbPr6TZ0A==";
    	String plaSharingDataStr = pe.decryptMode(merKey, encSharingDataStr);
    	System.out.println("分账解密明文:"+plaSharingDataStr);
    }
}
