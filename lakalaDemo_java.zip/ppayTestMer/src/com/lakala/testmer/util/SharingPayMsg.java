package com.lakala.testmer.util;

import java.util.Map;
import org.apache.log4j.Logger;

public class SharingPayMsg
{
  private static final Logger logger = Logger.getLogger(SharingPayMsg.class);
  private String inputcharset;
  private String version;
  private String protectPayState;
  private String language;
  private String signtype;
  private String pageurl;
  private String bgurl;
  private String transactionid;
  private String subtransactionid;
  private String taccountid;
  private String orderamount;
  private String payeeamount;
  private String ordertime;
  private String productname;
  private String productnum;
  private String productdesc;
  private String ext1;
  private String ext2;
  private String userphone;
  private String paytype;
  private String bankid;
  private String pid;
  private String sharingfeecalctype;
  private String sharingfeetype;
  private String haspayeefee;
  private String sharingdata;
  private String sharingpayflag;
  private String signmsg;

  public SharingPayMsg()
  {
  }

  public SharingPayMsg(String sharingPayMsgStr)
  {
  }
  public String getProtectPayState()
  {
    return this.protectPayState;
  }

  public void setProtectPayState(String protectPayState) {
    this.protectPayState = protectPayState;
  }

  private static String getValue(Map paramMap, String name)
  {
    Object o = paramMap.get(name);

    if (o == null) {
      logger.info(name + "=" + o);
      return null;
    }
    if (!o.getClass().isArray()) {
      logger.info(name + "=" + o.toString());
      return o.toString();
    }
    logger.info(name + "=" + ((Object[])o)[0].toString());
    return ((Object[])o)[0].toString();
  }

  public static SharingPayMsg getSharingPayMsg(Map paramMap)
  {
    SharingPayMsg sharingPayMsg = new SharingPayMsg();

    sharingPayMsg.setInputcharset(getValue(paramMap, "inputcharset"));
    sharingPayMsg.setVersion(getValue(paramMap, "version"));
    sharingPayMsg.setProtectPayState(getValue(paramMap, "protectPayState"));
    sharingPayMsg.setLanguage(getValue(paramMap, "language"));
    sharingPayMsg.setSigntype(getValue(paramMap, "signtype"));
    if (getValue(paramMap, "pageurl") != null) {
      sharingPayMsg.setPageurl(getValue(paramMap, "pageurl"));
    }
    if (getValue(paramMap, "bgurl") != null) {
      sharingPayMsg.setBgurl(getValue(paramMap, "bgurl"));
    }
    sharingPayMsg.setTransactionid(getValue(paramMap, "transactionid"));
    sharingPayMsg.setSubtransactionid(getValue(paramMap, "subtransactionid"));
    sharingPayMsg.setTaccountid(getValue(paramMap, "taccountid"));
    sharingPayMsg.setOrderamount(getValue(paramMap, "orderamount"));
    sharingPayMsg.setPayeeamount(getValue(paramMap, "payeeamount"));
    sharingPayMsg.setOrdertime(getValue(paramMap, "ordertime"));
    sharingPayMsg.setProductname(getValue(paramMap, "productname"));
    sharingPayMsg.setProductnum(getValue(paramMap, "productnum"));
    sharingPayMsg.setProductdesc(getValue(paramMap, "productdesc"));
    sharingPayMsg.setExt1(getValue(paramMap, "ext1"));
    sharingPayMsg.setExt2(getValue(paramMap, "ext2"));
    sharingPayMsg.setPaytype(getValue(paramMap, "paytype"));
    sharingPayMsg.setBankid(getValue(paramMap, "bankid"));
    sharingPayMsg.setUserphone(getValue(paramMap, "userphone"));
    sharingPayMsg.setPid(getValue(paramMap, "pid"));
    sharingPayMsg.setSharingfeecalctype(getValue(paramMap, "sharingfeecalctype"));
    sharingPayMsg.setSharingfeetype(getValue(paramMap, "sharingfeetype"));
    sharingPayMsg.setHaspayeefee(getValue(paramMap, "haspayeefee"));
    sharingPayMsg.setSharingdata(getValue(paramMap, "sharingdata"));
    sharingPayMsg.setSharingpayflag(getValue(paramMap, "sharingpayflag"));
    sharingPayMsg.setSignmsg(getValue(paramMap, "signmsg"));
    logger.info("参数获取成功");
    return sharingPayMsg;
  }

  public String getSharingPayStr()
  {
    StringBuffer sharingDataStr = new StringBuffer();

    if (getPageurl() != null) {
      sharingDataStr.append("pageurl=" + getPageurl() + "&");
    }

    if (getTransactionid() != null) {
      sharingDataStr.append("transactionid=" + getTransactionid() + "&");
    }

    if (getProtectPayState() != null) {
      sharingDataStr.append("protectPayState=" + getProtectPayState() + "&");
    }

    if (getOrderamount() != null) {
      sharingDataStr.append("orderamount=" + getOrderamount() + "&");
    }

    if (getOrdertime() != null) {
      sharingDataStr.append("ordertime=" + getOrdertime() + "&");
    }

    if ((getPaytype() != null) && (!"".equals(getPaytype())) && (!"null".equals(getPaytype()))) {
      sharingDataStr.append("paytype=" + getPaytype() + "&");
    }

    if (getPid() != null) {
      sharingDataStr.append("pid=" + getPid() + "&");
    }
    if (getSharingfeecalctype() != null) {
      sharingDataStr.append("sharingfeecalctype=" + getSharingfeecalctype() + "&");
    }
    if (getSharingfeetype() != null) {
      sharingDataStr.append("sharingfeetype=" + getSharingfeetype() + "&");
    }
    if (getHaspayeefee() != null) {
      sharingDataStr.append("haspayeefee=" + getHaspayeefee() + "&");
    }
    if (getSharingdata() != null) {
      sharingDataStr.append("sharingdata=" + getSharingdata() + "&");
    }

    if (getSharingpayflag() != null) {
      sharingDataStr.append("sharingpayflag=" + getSharingpayflag() + "&");
    }
    if (!sharingDataStr.toString().equals("")) {
      sharingDataStr.deleteCharAt(sharingDataStr.lastIndexOf("&"));
    }

    return sharingDataStr.toString();
  }

  public String getInputcharset() {
    return this.inputcharset;
  }

  public void setInputcharset(String inputcharset) {
    this.inputcharset = inputcharset;
  }

  public String getVersion() {
    return this.version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getLanguage() {
    return this.language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }

  public String getSigntype() {
    return this.signtype;
  }

  public void setSigntype(String signtype) {
    this.signtype = signtype;
  }

  public String getPageurl() {
    return this.pageurl;
  }

  public void setPageurl(String pageurl) {
    this.pageurl = pageurl;
  }

  public String getBgurl() {
    return this.bgurl;
  }

  public void setBgurl(String bgurl) {
    this.bgurl = bgurl;
  }

  public String getTransactionid() {
    return this.transactionid;
  }

  public void setTransactionid(String transactionid) {
    this.transactionid = transactionid;
  }

  public String getSubtransactionid() {
    return this.subtransactionid;
  }

  public void setSubtransactionid(String subtransactionid) {
    this.subtransactionid = subtransactionid;
  }

  public String getTaccountid() {
    return this.taccountid;
  }

  public void setTaccountid(String taccountid) {
    this.taccountid = taccountid;
  }

  public String getOrderamount() {
    return this.orderamount;
  }

  public void setOrderamount(String orderamount) {
    this.orderamount = orderamount;
  }

  public String getPayeeamount() {
    return this.payeeamount;
  }

  public void setPayeeamount(String payeeamount) {
    this.payeeamount = payeeamount;
  }

  public String getOrdertime() {
    return this.ordertime;
  }

  public void setOrdertime(String ordertime) {
    this.ordertime = ordertime;
  }

  public String getProductname() {
    return this.productname;
  }

  public void setProductname(String productname) {
    this.productname = productname;
  }

  public String getProductnum() {
    return this.productnum;
  }

  public void setProductnum(String productnum) {
    this.productnum = productnum;
  }

  public String getProductdesc() {
    return this.productdesc;
  }

  public void setProductdesc(String productdesc) {
    this.productdesc = productdesc;
  }

  public String getExt1() {
    return this.ext1;
  }

  public void setExt1(String ext1) {
    this.ext1 = ext1;
  }

  public String getExt2() {
    return this.ext2;
  }

  public void setExt2(String ext2) {
    this.ext2 = ext2;
  }

  public String getPaytype() {
    return this.paytype;
  }

  public void setPaytype(String paytype) {
    this.paytype = paytype;
  }

  public String getBankid() {
    return this.bankid;
  }

  public void setBankid(String bankid) {
    this.bankid = bankid;
  }

  public String getPid() {
    return this.pid;
  }

  public void setPid(String pid) {
    this.pid = pid;
  }

  public String getSharingfeecalctype() {
    return this.sharingfeecalctype;
  }

  public void setSharingfeecalctype(String sharingfeecalctype) {
    this.sharingfeecalctype = sharingfeecalctype;
  }

  public String getSharingfeetype() {
    return this.sharingfeetype;
  }

  public void setSharingfeetype(String sharingfeetype) {
    this.sharingfeetype = sharingfeetype;
  }

  public String getHaspayeefee() {
    return this.haspayeefee;
  }

  public void setHaspayeefee(String haspayeefee) {
    this.haspayeefee = haspayeefee;
  }

  public String getSharingdata() {
    return this.sharingdata;
  }

  public void setSharingdata(String sharingdata) {
    this.sharingdata = sharingdata;
  }

  public String getSharingpayflag() {
    return this.sharingpayflag;
  }

  public void setSharingpayflag(String sharingpayflag) {
    this.sharingpayflag = sharingpayflag;
  }

  public String getSignmsg() {
    return this.signmsg;
  }

  public void setSignmsg(String signmsg) {
    this.signmsg = signmsg;
  }

  public String getUserphone() {
    return this.userphone;
  }

  public void setUserphone(String userphone) {
    this.userphone = userphone;
  }
}