package com.lakala.testmer.util;

import com.lakala.aps.commons.ByteArrayUtil;
import org.apache.log4j.Logger;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PaySign {
	private static final Logger logger = Logger.getLogger(PaySign.class);
	
	public static String md5(String str) {
        //确定计算方法
        MessageDigest md5;
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
		byte[] data;
		try {
			data = str.getBytes("utf-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
		byte[] md5Date = md5.digest(data);
		return ByteArrayUtil.byteArray2HexString(md5Date);
	}
	
	public static String EncoderByMd5(String str) {
        //确定计算方法
        MessageDigest md5;
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
        byte[] data;
		try {
			data = str.getBytes("utf-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
        BASE64Encoder base64en = new BASE64Encoder();
        //加密后的字符串
        String newstr=base64en.encode(md5.digest(data));
        newstr = newstr.replaceAll("\\r|\\n", "");
        return newstr;
    }
	
	//签名参数说明:dataString签名串、key签名密钥
	public  String sign(String dataString,String key) throws EncException{
		String src = EncoderByMd5(dataString);
		PayEncrypt pe=new PayEncrypt();
		return pe.encryptMode(key,src);
	}
	public boolean verify(String dataString, String signString,String key) throws EncException{
		dataString=dataString.replace(" ", "+");
		signString=signString.replace(" ", "+");
		String destsrc=sign(dataString,key);

		if(destsrc.equals(signString)){
			return true;
		}else{
			logger.info("dataString="+dataString);
			logger.info("signString="+signString);
			logger.info("destsrc="+destsrc);
			logger.info("key="+key);
			return false;
		}
	}
	
	
	public static void main(String[] args) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		String dataString="105290054110500&2014-08-18: 14:26:09 987&vwkere93943-dkfaj&15910984019";
		String key = "YTDTJ1K6ABGT035V80HUMSLX";
		try {
			PaySign paySign = new PaySign();
			System.out.println("明文: "+dataString);
			System.out.println("密钥: "+key);
			String signString = paySign.sign(dataString, key);
			System.out.println("签名串: "+signString);
			System.out.println("签名串: "+paySign.verify(dataString, signString, key));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
