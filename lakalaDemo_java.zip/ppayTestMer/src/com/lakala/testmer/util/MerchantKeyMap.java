package com.lakala.testmer.util;

import org.apache.log4j.Logger;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by rishon on 2015/2/13.
 */
public class MerchantKeyMap {
    private final static Map<String, String> map = new ConcurrentHashMap<>();
    private final static Object[] lock = new Object[0];
    private MerchantKeyMap(){}

    public static String getKey(String merchantId) {

        if (map.containsKey(merchantId)) return map.get(merchantId);

        synchronized (lock) {
            if (map.containsKey(merchantId)) return map.get(merchantId);

            String key = Tools.getRandomString(32);
            map.put(merchantId, key);
            return key;
        }
    }

}
