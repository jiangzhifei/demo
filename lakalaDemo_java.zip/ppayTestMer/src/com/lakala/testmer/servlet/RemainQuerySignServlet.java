package com.lakala.testmer.servlet;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;

import com.lakala.pay.service.DovePayService;
import com.lakala.pay.service.DovePayServiceServiceLocator;
import com.lakala.testmer.util.RemainPayMsg;

public class RemainQuerySignServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RemainQuerySignServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//参数
		String pid=request.getParameter("pid");
		String taccountid=request.getParameter("taccountid");
		String spid=request.getParameter("spid");
		//签名
		String paramStr ="pid="+pid+"&taccountid="+taccountid+"&spid="+spid ;
		//调用webService
		DovePayServiceServiceLocator dss= new DovePayServiceServiceLocator();
		try {
			DovePayService  ds=(DovePayService)dss.getDovePayService();
			//预付费交易
			String result=ds.queryRemain(paramStr);
			request.setAttribute("result", result);
		} catch (ServiceException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher("remainQueryResult.jsp").forward(request, response);
	}

}
