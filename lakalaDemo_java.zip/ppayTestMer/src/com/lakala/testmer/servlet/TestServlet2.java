package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lakala.testmer.util.HttpRequest;
import com.lakala.testmer.util.HttpResponse;

public class TestServlet2 extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HashMap map=new HashMap();
		map.put("m", "value");
		HttpRequest hr = new HttpRequest();
		HttpResponse httpResponse = hr.sendPost("http://localhost:8088/ppayTestMer/text.asp", map);
		String resStr = httpResponse.getContent();
		System.out.println(resStr);
	}

}
