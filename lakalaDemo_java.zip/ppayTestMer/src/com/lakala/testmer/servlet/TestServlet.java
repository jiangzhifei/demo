package com.lakala.testmer.servlet;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.testmer.util.EncException;
import com.lakala.testmer.util.HttpRequest;
import com.lakala.testmer.util.HttpResponse;
import com.lakala.testmer.util.PaySign;

public class TestServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(TestServlet.class);
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String transactionid = request.getParameter("transactionid");
		String mertype = request.getParameter("mertype");
		String mername = request.getParameter("mername");
		String industry = request.getParameter("industry");
		String name = request.getParameter("name");
		String nature = request.getParameter("nature");
		String certtype = request.getParameter("certtype");
		String certcode = request.getParameter("certcode");
		String zipcode = request.getParameter("zipcode");
		String addr = request.getParameter("addr");
		String email = request.getParameter("email");
		String pid = request.getParameter("pid");
		String url = request.getParameter("url");
		StringBuffer paramStr = new StringBuffer();
		Map<String,String> paramMap = new HashMap<String,String>();
		paramMap.put("transactionid", URLEncoder.encode(transactionid,"utf-8"));
		paramMap.put("mertype", URLEncoder.encode(mertype,"utf-8"));
		paramMap.put("industry", URLEncoder.encode(industry,"utf-8"));
		paramMap.put("name", URLEncoder.encode(name,"utf-8"));
		paramMap.put("nature", URLEncoder.encode(nature,"utf-8"));
		paramMap.put("certtype", URLEncoder.encode(certtype,"utf-8"));
		paramMap.put("certcode", URLEncoder.encode(certcode,"utf-8"));
		paramMap.put("zipcode", URLEncoder.encode(zipcode,"utf-8"));
		paramMap.put("addr", URLEncoder.encode(addr,"utf-8"));
		paramMap.put("email", URLEncoder.encode(email,"utf-8"));
		paramMap.put("pid", URLEncoder.encode(pid,"utf-8"));
		paramMap.put("mername", URLEncoder.encode(mername,"utf-8"));
		if(transactionid!=null){
			paramStr.append("transactionid="+transactionid+"&");
		}
		if(mertype!=null){
			paramStr.append("mertype="+mertype+"&");
		}
		if(mername!=null){
			paramStr.append("mername="+mername+"&");
		}
		if(industry!=null){
			paramStr.append("industry="+industry+"&");
		}
		if(name!=null){
			paramStr.append("name="+name+"&");
		}
		if(nature!=null){
			paramStr.append("nature="+nature+"&");
		}
		if(certtype!=null){
			paramStr.append("certtype="+certtype+"&");
		}
		if(certcode!=null){
			paramStr.append("certcode="+certcode+"&");
		}
		if(zipcode!=null){
			paramStr.append("zipcode="+zipcode+"&");
		}
		if(addr!=null){
			paramStr.append("addr="+addr+"&");
		}
		if(email!=null){
			paramStr.append("email="+email+"&");
		}
		if(pid!=null){
			paramStr.append("pid="+pid+"&");
		}
		if(paramStr.indexOf("&")!=-1){
			paramStr.deleteCharAt(paramStr.lastIndexOf("&"));
		}
		//System.out.println("testServlet-------------"+paramStr.toString());
		String merKey = "GheuVsd21ppay5J52DwfjTay";
		PaySign ps = new PaySign();
		try {
			String signmsg = ps.sign(paramStr.toString(), merKey);
			//System.out.println("signmsg = "+signmsg);
			paramMap.put("signmsg", URLEncoder.encode(signmsg,"utf-8"));
			logger.info("signmsg:testservlet-----------"+signmsg);
			HttpRequest hr = new HttpRequest();
			HttpResponse httpResponse = hr.sendPost(url, paramMap);
			String resStr = httpResponse.getContent();
			if(resStr!=null){
				String[] resArr = resStr.split("&");
				for(int i=0;i<resArr.length;i++){
					String[] kvArr = resArr[i].split("=");
					if(kvArr[0].equals("transactionid")){
						response.getOutputStream().write(("商户交易号:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("pid")){
						response.getOutputStream().write(("商户标识:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("taccountid")){
						response.getOutputStream().write(("帐户标识:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("retcode")){
						response.getOutputStream().write(("响应码:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("loginpwd")){
						response.getOutputStream().write(("登录密码:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("paypwd")){
						response.getOutputStream().write(("支付密码:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("merkey")){
						response.getOutputStream().write(("接口密钥:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("recvtime")){
						response.getOutputStream().write(("受理时间:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("signmsg")){
						response.getOutputStream().write(("签名:"+kvArr[1]+"<br>").getBytes()); 
					}
				}
			}
			response.getOutputStream().flush();   
			response.getOutputStream().close();
			System.out.println("ppayTestMer:"+httpResponse.getContent());
		} catch (EncException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
