package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.aps.commons.StringUtils;
import com.lakala.testmer.util.DESCrypto;
import com.lakala.testmer.util.DigestUtil;
import com.lakala.testmer.util.HttpHelper;
import com.lakala.testmer.util.RSAUtil;
import com.lakala.testmer.util.Tools;


@WebServlet("/queryStatusServlet")
public class QueryStatusServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(QueryStatusServlet.class);
	public static final String QUERY_STATUS = "queryStatus";
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		logger.info("开始产生代付订单");
		request.setCharacterEncoding("utf-8");
		
		String platformPublicKey = "";
		String merPrivateKey = "";
		String jsonStr = "";												// json字符串
		String encData = "";												// 加密json字符串
		String merDesStr = "";												// 商户对称秘钥
		String encKey = "";									
		String encKeyStr = "";
		String macStr = "";
		String mac = "";
	
		String ver = request.getParameter("ver");							// 协议版本号
		String merId = request.getParameter("merId");						// 商户号
		String ts = request.getParameter("ts");
		String merOrderId = request.getParameter("merOrderId");
		
		String gateUrl = "";												// 网关地址
		String addOrderUrl = "";
		
		platformPublicKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "pingtaiPublicKey");
		merPrivateKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), merId);
		merDesStr = Tools.getRandomString(32);
		encKeyStr = ts + merDesStr;
		
		gateUrl = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "gateUrl");
		
		try {
			encKey = ByteArrayUtil.byteArray2HexString(RSAUtil.encryptByPublicKey(encKeyStr.getBytes(), platformPublicKey));
		} catch (Exception e) {
			logger.error("加密对称密钥失败", e);
		}
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("merOrderId", merOrderId);
		
		jsonStr = JsonUtil.map2Json(params);
		encData = ByteArrayUtil.byteArray2HexString(DESCrypto.enCrypto(jsonStr.getBytes(), merDesStr));
		
		// 需要做mac的字段包括商户号、版本号、时间戳、加密Json
		macStr = merId + ver + ts + encData;
		
		// SHA1
		macStr = DigestUtil.Encrypt(macStr, "SHA-1");
		
		try {
			mac = ByteArrayUtil.byteArray2HexString(RSAUtil.encryptByPrivateKey(macStr.getBytes(), merPrivateKey));
		} catch (Exception e) {
			logger.error("生成MAC失败", e);
		}
		
		addOrderUrl = gateUrl + QUERY_STATUS;
		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put("ver", ver);
		reqMap.put("merId", merId);
		reqMap.put("ts", ts);
		reqMap.put("encKey", encKey);
		reqMap.put("encData", encData);
		reqMap.put("mac", mac);
		
		String result = HttpHelper.doHttp(addOrderUrl, HttpHelper.POST, "UTF-8", JsonUtil.map2Json(reqMap), "5500000");
		logger.info("result:" + result);
		
		if (result == null) {
			logger.error("支付平台返回null");
			return ;
		}
		
		Map<String, String> retMap = JsonUtil.jsonToMap(result);
		String retVer = retMap.get("ver");
		String retMerId = retMap.get("merId");
		String retTs = retMap.get("ts");
		String retEncData = retMap.get("encData");
		String retMac = retMap.get("mac");
		String retCode = retMap.get("retCode");
		String retMsg = retMap.get("retMsg");
		
		if (retCode == null || !retCode.equals("0000")) {
			logger.error("下单失败 ret=" + retMap.toString());
			request.setAttribute("retMsg",retMsg);
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("queryStatusRet.jsp").forward(request, response);
			return;
		}
		
		String retMacStr = DigestUtil.Encrypt(retCode + retMsg + retMerId + retVer + retTs + retEncData, "SHA-1");
		logger.info("SHA-1加密响应返回的mac" + retMacStr);
		String reqMacStr = "";
		
		try {
			reqMacStr = new String(RSAUtil.decryptByPublicKey(ByteArrayUtil.hexString2ByteArray(retMac), platformPublicKey));
		} catch (Exception e) {
			logger.error("解密MAC失败", e);
			request.setAttribute("retMsg","解密MAC失败");
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("queryStatusRet.jsp").forward(request, response);
			return;
		}
		
		String resData = "";
		try {
			logger.info(retEncData);
			byte[] byte_retEncData = ByteArrayUtil.hexString2ByteArray(retEncData);

			byte[] tmp1 = DESCrypto.deCrypt(byte_retEncData, merDesStr);
			resData = new String(tmp1);
			logger.info("res:" + result);
			logger.info("业务响应结果：" + resData);
			
		} catch (Exception e) {
			logger.error("", e);
			request.setAttribute("retMsg", retMsg);
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("queryStatusRet.jsp").forward(request, response);
			return;
		}
		
		
		logger.info("代付订单完成");
		
		Map<String,String> ywMap = JsonUtil.jsonToMap(resData);
		request.setAttribute("retMsg", retMsg);
		request.setAttribute("retCode", retCode);
		request.setAttribute("merOrderId", String.valueOf(ywMap.get("merOrderId")));
		request.setAttribute("orderTime", String.valueOf(ywMap.get("orderTime")));
		request.setAttribute("currency", String.valueOf(ywMap.get("currency")));
		request.setAttribute("amount", String.valueOf(ywMap.get("amount")));
		request.setAttribute("payResult", String.valueOf(ywMap.get("payResult")));
		request.setAttribute("transactionId", String.valueOf(ywMap.get("transactionId")));
		request.setAttribute("fee", String.valueOf(ywMap.get("fee")));
		
		request.getRequestDispatcher("queryStatusRet.jsp").forward(request, response);
	}
}
