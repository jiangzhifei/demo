package com.lakala.testmer.servlet;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.pay.service.DovePayService;
import com.lakala.pay.service.DovePayServiceServiceLocator;
import com.lakala.testmer.util.PaySign;

/**
 * Servlet implementation class WebQueryOrderServlet
 */
public class WebQueryOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(WebQueryOrderServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WebQueryOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = request.getParameter("url");
		String pid = request.getParameter("pid");
		String transactionid = request.getParameter("transactionid");
		String dealid = request.getParameter("dealid");
		String merKey = "GheuVsd21ppay5J52DwfjTay";
		StringBuffer paramStr = new StringBuffer();
			paramStr.append("pid="+pid+"&");
			paramStr.append("transactionid="+transactionid+"&");
			paramStr.append("dealid="+dealid+"&");
			paramStr.deleteCharAt(paramStr.lastIndexOf("&"));
		//签名
		PaySign ps = new PaySign();
		try {
			String signmsg = ps.sign(paramStr.toString(), merKey);
			System.out.println("signmsg = "+signmsg);
			paramStr.append("&signmsg=").append(signmsg);
			DovePayServiceServiceLocator dpsl=new DovePayServiceServiceLocator();
			DovePayService dps=dpsl.getDovePayService();
			String returnStr=dps.queryOrder(paramStr.toString());
			System.out.println("------query-----"+returnStr);
			if(returnStr!=null){
				String newStr=returnStr.replace("=&", "=null&");
				String[] resArr = newStr.split("&");
				for(int i=0;i<resArr.length;i++){
					String[] kvArr = resArr[i].split("=");
					if(kvArr[0].equals("paytype")){
						response.getOutputStream().write(("支付方式:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("bankid")){
						response.getOutputStream().write(("银行代码:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("pid")){
						response.getOutputStream().write(("商户标识:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("transactionid")){
						response.getOutputStream().write(("商户交易号:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("ordertime")){
						response.getOutputStream().write(("商户订单提交时间:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("orderamount")){
						response.getOutputStream().write(("商户订单金额:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("dealid")){
						response.getOutputStream().write(("支付平台交易号:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("bankdealid")){
						if(kvArr.length==2){
						response.getOutputStream().write(("银行交易号:"+kvArr[1]+"<br>").getBytes()); 
						}else{
							response.getOutputStream().write(("银行交易号:"+""+"<br>").getBytes()); 
						}
					}
					if(kvArr[0].equals("dealtime")){
						response.getOutputStream().write(("支付平台交易时间:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("payamount")){
						response.getOutputStream().write(("订单实际支付金额:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("dealbank")){
						response.getOutputStream().write(("支付银行名:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("dealaccount")){
						response.getOutputStream().write(("支付账号:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("fee")){
						response.getOutputStream().write(("费用:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("payeecontacttype")){
						response.getOutputStream().write(("主收款方联系方式类型:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("payeecontact")){
						response.getOutputStream().write(("主收款方联系方式:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("payeeamount")){
						response.getOutputStream().write(("主收款方收到金额:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("ext1")){
						response.getOutputStream().write(("扩展字段1:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("ext2")){
						response.getOutputStream().write(("扩展字段2:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("paymentcode")){
						response.getOutputStream().write(("商户参数字段:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("payresult")){
						response.getOutputStream().write(("处理结果:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("sharingresult")){
						response.getOutputStream().write(("分账结果:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("errcode")){
						response.getOutputStream().write(("错误代码:"+kvArr[1]+"---"+CodeUtil.errCode(kvArr[1])+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("signmsg")){
						response.getOutputStream().write(("签名:"+kvArr[1]+"<br>").getBytes()); 
					}
				}
			} 
			response.getOutputStream().flush();   
			response.getOutputStream().close();
	
		}catch(Exception e){
			logger.error(e);
		}
		
	}

}
