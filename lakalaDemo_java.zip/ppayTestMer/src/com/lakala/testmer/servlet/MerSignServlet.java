package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.testmer.util.EncException;
import com.lakala.testmer.util.PayEncrypt;
import com.lakala.testmer.util.PaySign;
import com.lakala.testmer.util.PropertiesConfigUtil;
import com.lakala.testmer.util.SharingPayMsg;

/**
 * Servlet implementation class MerSignServlet
 */
public class MerSignServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(MerSignServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MerSignServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Map map = request.getParameterMap();
		String version = request.getParameter("version");
		SharingPayMsg sharingPayMsg = SharingPayMsg.getSharingPayMsg(map);
		// 对分账数据进行加密
		PayEncrypt pe = new PayEncrypt();
		String sharingData = "";

		String servletContextPath = request.getServletContext().getRealPath("/");
		String proFile = servletContextPath + "/WEB-INF/classes/site.properties";
		Properties prop = new Properties();
		prop = PropertiesConfigUtil.load(proFile);
		String merKey = prop.getProperty(sharingPayMsg.getPid());
		try {
			sharingData = pe.encryptMode(merKey, request.getParameter("sharingdata"));
			logger.info("sharingData:" + sharingData);
			sharingPayMsg.setSharingdata(sharingData);
		} catch (EncException e) {
			e.printStackTrace();
		}
		// 签名
		PaySign ps = new PaySign();
		String signmsg;
		String sharingPayStr = sharingPayMsg.getSharingPayStr();
		try {
			signmsg = ps.sign(sharingPayStr, merKey);
			sharingPayMsg.setSignmsg(signmsg);
			logger.info("sharingPayStr:" + sharingPayStr + ",signmsg:" + signmsg + ",merKey:" + merKey);
		} catch (EncException e) {
			e.printStackTrace();
		}
		request.setAttribute("version", version);
		request.setAttribute("sharingPayMsg", sharingPayMsg);
		request.getRequestDispatcher("merOrder2DovePay.jsp").forward(request, response);
	}

}
