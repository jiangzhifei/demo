package com.lakala.testmer.servlet;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.aps.commons.StringUtils;
import com.lakala.testmer.util.*;

import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * 跨境支付商户下单
 *
 */
public class CreateOrderServlet extends HttpServlet {

	private static final Logger logger = Logger.getLogger(CreateOrderServlet.class);
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		logger.info("下单");

		String ts = request.getParameter("ts");
		String ver = request.getParameter("ver");//协议版本号
		String merId = request.getParameter("merId");//商户号
		String reqType = request.getParameter("reqType");//请求业务类型
		
		String merOrderId = request.getParameter("merOrderId");
//		String custId = request.getParameter("custId");
		String currency = request.getParameter("currency");
		String orderAmount = request.getParameter("orderAmount");

		String busiRange = request.getParameter("busiRange");
		String orderSummary = request.getParameter("orderSummary");
		String orderTime = request.getParameter("orderTime");
		String timeZone = request.getParameter("timeZone");
		String pageUrl = request.getParameter("pageUrl");
		String bgUrl = request.getParameter("bgUrl");
		String ext1 = request.getParameter("ext1");//扩展字段1
		String ext2 = request.getParameter("ext2");//扩展字段2
		String orderEffTime = request.getParameter("orderEffTime");//订单有效时间
		
		String cuId = request.getParameter("cuId");						// 海关id
		String bizTypeCode = request.getParameter("bizTypeCode");		// 业务类型
		String goodsFee = request.getParameter("goodsFee");				// 商品货款金额
		String taxFee = request.getParameter("taxFee");					// 税款金额
		String buyForexKind = request.getParameter("buyForexKind");					// 购汇种类
		
//		clientName = "霍亮";
		//提供给商户的平台公钥
		String pingtaiPublicKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "pingtaiPublicKey");
		//商户的私钥
		String merPrivateKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), merId);
		
		//1.商户随机3DES对称密钥
		String merDesStr = MerchantKeyMap.getKey(merId);
		//2.时间戳
		String dateStr = ts;//"2014110719160012";
		
		String encKey = "";
		String encKeyStr = dateStr+merDesStr;
		logger.info("时间戳拼接对称密钥encKeyStr==="+encKeyStr);
		//3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
		try {
			encKey = ByteArrayUtil.byteArray2HexString(RSAUtil.encryptByPublicKey(encKeyStr.getBytes(), pingtaiPublicKey));
		} catch (Exception e) {
			logger.error("加密对称密钥失败", e);
		}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("merOrderId", merOrderId);
		params.put("ts", ts);
//		params.put("custId", custId);
		params.put("currency", currency);
		params.put("orderAmount", orderAmount);
		params.put("bizCode", busiRange);
		params.put("orderSummary", orderSummary);
		params.put("orderTime", orderTime);
		params.put("timeZone", timeZone);
		params.put("pageUrl", pageUrl);
		params.put("bgUrl", bgUrl);
		params.put("ext1", ext1);
		params.put("ext2", ext2);
		params.put("orderEffTime", orderEffTime);
		
		//扩展字段
		Map<String, String> extensionMap = new HashMap<String, String>();
		extensionMap.put("cuId", cuId);
		extensionMap.put("bizTypeCode", bizTypeCode);
		extensionMap.put("goodsFee", goodsFee);
		extensionMap.put("taxFee", taxFee);
		extensionMap.put("buyForexKind", buyForexKind);
		
		params.put("extension", extensionMap);
		
		
		//代收白名单模式
		String isDirectPay = request.getParameter("isDirectPay");//是否启用白名单
		String merClientId = request.getParameter("merClientId");//商户客户会员号
		String signDealNumber = request.getParameter("signDealNumber");//签约协议号
		params.put("isDirectPay", isDirectPay);
		params.put("merClientId", merClientId);
		params.put("signDealNumber", signDealNumber);
		
		String json = JsonUtil.map2Json(params);
		//加密请求业务json
		String json1 = ByteArrayUtil.byteArray2HexString(DESCrypto.enCrypto(json.getBytes(), merDesStr));
		
		//拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
		// 拼接
        String macStr = merId + ver + dateStr + reqType + json1;
        // SHA1
		macStr = DigestUtil.Encrypt(macStr, "SHA-1");
		String mac = "";
		try {
			mac = ByteArrayUtil.byteArray2HexString(RSAUtil.encryptByPrivateKey(macStr.getBytes(), merPrivateKey));
		} catch (Exception e) {
			logger.error("生成MAC失败", e);
		}
		
		String url = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "ppayGateUrl.H5End");

        if (!url.startsWith("http"))
            url = "http://"+ request.getLocalAddr()+":" + request.getLocalPort()+ url;

		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put("ver", ver);
		reqMap.put("merId", merId);
		reqMap.put("ts", dateStr);
		reqMap.put("reqType", reqType);
		reqMap.put("encKey", encKey);
		reqMap.put("encData", json1);
		reqMap.put("mac", mac);

		request.setAttribute("jumpUrl", url);
		request.setAttribute("jumpData", reqMap);

		request.getRequestDispatcher("jumpUrl.jsp").forward(request, response);

	}
	
}
