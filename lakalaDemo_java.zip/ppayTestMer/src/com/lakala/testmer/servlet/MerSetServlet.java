package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.pay.service.MerInterfaceService;
import com.lakala.testmer.util.DESCrypto;
import com.lakala.testmer.util.DigestUtil;
import com.lakala.testmer.util.HttpHelper;
import com.lakala.testmer.util.PropertiesConfigUtil;
import com.lakala.testmer.util.RSAUtil;
import com.lakala.testmer.util.Tools;

public class MerSetServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(MerSetServlet.class);
	private static final long serialVersionUID = 1L;
    public MerSetServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		try{
			//获取请求参数
			String merId = request.getParameter("merId"); //商户号
			String startDate = request.getParameter("startDate"); //开始时间
			String endDate = request.getParameter("endDate"); //结束时间
			String notifyAddr = request.getParameter("notifyAddr"); //通知商户地址
			String reqType = request.getParameter("reqType");//业务类型
			String ver = request.getParameter("version"); //版本号
			logger.info("[商户对账请求]请求处理开始,merId="+merId+",startDate="+startDate+",endDate="+endDate+",notifyAddr="+notifyAddr+",version="+ver);

			//提供给商户的平台公钥
			String pingtaiPublicKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "pingtaiPublicKey");
			//商户的私钥
			String merPrivateKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "merPrivateKey");
			
			//1.商户随机3DES对称密钥
			String merDesStr = Tools.getRandomString(32);
			//2.时间戳
			String dateStr = MerInterfaceService.getTs();
			logger.info("商户生产时间戳dateStr==="+dateStr);
			//3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
			String encKey = MerInterfaceService.getMerEncKey();
			logger.info("时间戳拼接对称密钥hexencKey==="+encKey);
			//4.用对称密钥3DES加密“请求业务json”，生成“加密json1”
			Map map = new HashMap();
			map.put("merId", merId);
			map.put("startDate", startDate);
			map.put("endDate", endDate);
			map.put("notifyAddr", notifyAddr);

			
			String json = JsonUtil.map2Json(map);
			logger.info("业务参数原文json==="+json);
			String json1 = MerInterfaceService.getJson1(json);
			logger.info("使用对称密钥加密以后的json1==="+json1);
			//拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
			String macStr1 = merId + ver + dateStr + reqType + json1;
			String macStr = MerInterfaceService.getMacStr(macStr1);
			String mac = MerInterfaceService.getMac(macStr,merId);
			logger.info("商户私钥加密以后的mac==="+mac);
			
			String url = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "ppayGateUrl");
			Map reqMap = new HashMap();
			reqMap.put("ver", ver);
			reqMap.put("merId", merId);
			reqMap.put("ts", dateStr);
			reqMap.put("reqType", reqType);
			reqMap.put("encKey", encKey);
			reqMap.put("encData", json1);
			reqMap.put("mac", mac);
			logger.info("req:" + JsonUtil.map2Json(reqMap));
			
			String result = HttpHelper.doHttp(url, HttpHelper.POST, "UTF-8", JsonUtil.map2Json(reqMap), "60000");
			if (result == null) {
				logger.error("对账文件下载返回为空！");
				return ;
			}
			Map<String, String> retMap = JsonUtil.jsonToMap(result);
			String retVer = retMap.get("ver");
			String retMerId = retMap.get("merId");
			String retTs = retMap.get("ts");
			String retReqType = retMap.get("reqType");
			String retEncData = retMap.get("encData");
			String retMac = retMap.get("mac");
			String retCode = retMap.get("retCode");
			String retMsg = retMap.get("retMsg");
			if (retCode == null || !retCode.equals("0000")) {
				logger.error("对账文件下载失败！ ret=" + retMap.toString());
				request.setAttribute("retMsg",retMsg);
				request.setAttribute("retCode", retCode);
				request.getRequestDispatcher("sendMerSet.jsp").forward(request, response);
				return;
			}
			
			String retMacStr = DigestUtil.Encrypt(retTs+retReqType+retEncData, "SHA-1");
			logger.info("SHA-1加密响应返回的mac"+retMacStr);
			String reqMacStr = "";
			try {
				reqMacStr = new String(RSAUtil.decryptByPublicKey(ByteArrayUtil.hexString2ByteArray(retMac), pingtaiPublicKey));
			} catch (Exception e) {
				logger.error("解密MAC失败", e);
				request.setAttribute("retMsg","解密MAC失败");
				request.setAttribute("retCode", retCode);
				request.getRequestDispatcher("MerSet.jsp").forward(request, response);
				return;
			}
			String reqData = "";
			try {
				reqData = MerInterfaceService.getReqData(retEncData);
			} catch (Exception e) {
				e.printStackTrace();
			}
			Map<String, String> resultMap = JsonUtil.jsonToMap(reqData);
			
			request.setAttribute("retMsg", retMsg);
			request.setAttribute("retCode", retCode);
			
			//响应结果
			request.getRequestDispatcher("MerSet.jsp").forward(request, response);
		}catch(Exception e){
			logger.error("[获取商户对账请求处理异常]",e);
		}
	}

}
