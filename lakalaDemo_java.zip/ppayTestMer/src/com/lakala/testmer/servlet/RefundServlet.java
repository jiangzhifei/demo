package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.lakala.testmer.util.PaySign;
import com.lakala.testmer.util.PropertiesConfigUtil;

/**
 * 模拟商户订单退款
 */
public class RefundServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(RefundServlet.class);
	private static final long serialVersionUID = 1L;

	public RefundServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		try {
			// 获取请求参数
			String seqId = request.getParameter("seqId"); // 流水号
			String transactionId = request.getParameter("transactionId"); // 原支付商户订单号
			String pId = request.getParameter("pId"); // 原支付商户订单号
			String refundAmt = request.getParameter("refundAmt"); // 退款金额
			String refundTime = request.getParameter("refundTime"); // 商户订单时间
			String version = request.getParameter("version"); // 版本号
			logger.info("[商户订单退款请求]seqId=" + seqId + ",transactionId=" + transactionId + ",pId=" + pId + ",refundAmt=" + refundAmt + ",refundTime="
					+ refundTime);
			// 参数校验
			if (StringUtils.isEmpty(seqId)) {
				logger.error("0001,流水号为空");
				return;
			}
			if (StringUtils.isEmpty(transactionId)) {
				logger.error("0002,原支付订单号为空");
				return;
			}
			if (StringUtils.isEmpty(pId)) {
				logger.error("0003,商户号为空");
				return;
			}
			if (StringUtils.isEmpty(refundAmt)) {
				logger.error("0004,退款金额为空");
				return;
			}
			if (StringUtils.isEmpty(refundTime)) {
				logger.error("0010,退款时间为空");
				return;
			}
			if (StringUtils.isEmpty(version)) {
				logger.error("0011,版本号为空");
				return;
			}

			//拼接明文签名串
			StringBuffer sb = new StringBuffer();
			sb.append("seqId=").append(seqId);
			sb.append("&").append("transactionId=").append(transactionId);
			sb.append("&").append("pId=").append(pId);
			sb.append("&").append("refundAmt=").append(refundAmt);
			sb.append("&").append("refundTime=").append(refundTime);
			sb.append("&").append("version=").append(version);
			String minData = sb.toString();
			
			// 签名处理
			String servletContextPath = request.getServletContext().getRealPath("/");
			String proFile = servletContextPath + "/WEB-INF/classes/site.properties";
			Properties prop = new Properties();
			prop = PropertiesConfigUtil.load(proFile);
			String merKey = prop.getProperty(pId);
			PaySign ps = new PaySign();
			String signData = ps.sign(minData, merKey);

			// 接口调用
			Map<String, String> map = new HashMap<String, String>();
			map.put("seqId", seqId);
			map.put("transactionId", transactionId);
			map.put("pId", pId);
			map.put("refundAmt", refundAmt);
			map.put("refundTime", refundTime);
			map.put("version", version);
			map.put("signData", signData);
			request.setAttribute("reqMap", map);
			// 响应结果
			request.getRequestDispatcher("sendRefundOrder.jsp").forward(request, response);
			logger.error("[商户订单退款请求]查询处理结束");
			return;
		} catch (Exception e) {
			logger.error("[获取商户订单退款请求处理异常]", e);
		} finally {
		}
		logger.info("[商户订单退款请求]请求处理结束");
	}

}
