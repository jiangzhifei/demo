package com.lakala.testmer.servlet;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;

import com.lakala.pay.service.DovePayService;
import com.lakala.pay.service.DovePayServiceServiceLocator;
import com.lakala.testmer.util.EncException;
import com.lakala.testmer.util.PaySign;
import com.lakala.testmer.util.RemainPayMsg;

public class RemainPaySignServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RemainPaySignServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Map map = request.getParameterMap();
		String merKey = "GheuVsd21ppay5J52DwfjTay";
		RemainPayMsg sharingPayMsg = RemainPayMsg.getSharingPayMsg(map);
		//签名
		PaySign ps=new PaySign();
		String sharingPayStr = sharingPayMsg.getSharingPayStr();
		String signmsg=null;
		try {
			signmsg = ps.sign(sharingPayStr,merKey);
		} catch (EncException e) {
			e.printStackTrace();
		}
		String payStr=sharingPayMsg.getPayStr()+"&signmsg="+signmsg;
		System.out.println("-------------------------------"+payStr);
		//调用webService
		DovePayServiceServiceLocator dss= new DovePayServiceServiceLocator();
		try {
			DovePayService  ds=(DovePayService)dss.getDovePayService();
			//预付费交易
			String result=ds.prePaid(payStr);
			request.setAttribute("result", result);
		} catch (ServiceException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher("remainPayResult.jsp").forward(request, response);
	}

}
