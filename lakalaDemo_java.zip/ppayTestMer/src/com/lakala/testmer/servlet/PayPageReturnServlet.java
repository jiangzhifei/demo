package com.lakala.testmer.servlet;

import com.lakala.aps.commons.*;
import com.lakala.testmer.util.*;
import com.lakala.testmer.util.RSAUtil;

import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
/**
 * Servlet implementation class MerSignServlet
 */

/**
 * 页面支付结果通知
 *
 */
public class PayPageReturnServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(PayPageReturnServlet.class);


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		logger.info("testMer------处理支付结果通知doPost");
		PrintWriter writer = null;

		try {
			String reqJson = null;

			@SuppressWarnings("rawtypes")
			Map jsonMap = new HashMap();
            Enumeration enumeration = request.getParameterNames();
            String name;
            while (enumeration.hasMoreElements()){
                name = (String)enumeration.nextElement();
                jsonMap.put(name, request.getParameter(name));
            }


            String merId = (String)jsonMap.get("merId");

			// 获取商户私钥
			String merPrivateKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), merId);

			//获取平台公钥
			String platPublicKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "pingtaiPublicKey");

            if (jsonMap.get("encData") != null) {

                // 解密、验证mac
                Map retMap = decryptReqData(jsonMap, platPublicKey, merPrivateKey);
                logger.info("解密验签成功");

                String reqData = (String) retMap.get("reqData");
                jsonMap.putAll(retMap);

                if (StringUtils.isNotEmpty(reqData))
                    jsonMap.putAll(JsonUtil.jsonToMap(reqData));
            }

			logger.info("处理返回信息：" + jsonMap);

            request.setAttribute("__display_data__", jsonMap);
            request.getRequestDispatcher("pageResult.jsp").forward(request, response);
            // 6. 返回响应

		} catch (Exception e) {
			logger.error("系统异常",e);
			return;
		}

	}

	/**
	 * 在post请求中获取报文
	 *
	 * @param request
	 * @return
	 * @throws java.io.IOException
	 */
	private String getRequestPostBytes(HttpServletRequest request)
			throws IOException {
		int contentLength = request.getContentLength();
		if (contentLength < 0) {
			return null;
		}
		byte buffer[] = new byte[contentLength];
		for (int i = 0; i < contentLength;) {
			int readlen = request.getInputStream().read(buffer, i,
					contentLength - i);
			if (readlen == -1) {
				break;
			}
			i += readlen;
		}
		return new String(buffer, "utf-8");
	}

	/**
	 * 获取时间戳--非实际意义的时间戳
	 *
	 * @return
	 */
	public String getTs() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String str = sdf.format(new Date());
		String s = System.currentTimeMillis() + "";
		return str + s.substring(7);
	}


	/**
	 * 解密请求数据
	 *
	 * @param params
	 *            平台请求原始数据
	 * @param platPublicKey
	 *            平台公钥
	 * @param merPrivateKey
	 *            商户私钥
	 * @return
	 */
	private Map<String, String> decryptReqData(Map<String, String> params,
			String platPublicKey, String merPrivateKey) {
        // 响应码
        String retCode = (String) params.get("retCode");
        String retMsg = (String) params.get("retMsg");

		String ts = (String) params.get("ts");
		String reqType = (String) params.get("reqType");
		String reqEncData = (String) params.get("encData");
		String reqMac = (String) params.get("mac");
        String merId = (String)params.get("merId");
        String ver = (String)params.get("ver");

        // 用请求方公钥验签（拼接时间戳、业务类型、“加密json1”做SHA1，用请求方公钥解密mac反hex的字节数组，比较是否一致）
        String macData = DigestUtil.Encrypt(retCode + retMsg + merId + ver + ts + reqType + reqEncData, "SHA-1", "GBK");
		String reqMacStr = "";
		try {
			reqMacStr = new String(RSAUtil.decryptByPublicKey(
					ByteArrayUtil.hexString2ByteArray(reqMac), platPublicKey));
		} catch (Exception e) {
			logger.error("解密mac失败", e);
			params.put("retCode", CrossBorderConstant.ERROR_0016);
			params.put("retMsg", CrossBorderConstant.ERROR_0016_MSG);
			return params;
		}
		// mac校验
		if (!macData.equals(reqMacStr)) {
			logger.error("mac校验失败");
			params.put("retCode", CrossBorderConstant.ERROR_0015);
			params.put("retMsg", CrossBorderConstant.ERROR_0015_MSG);
			return params;
		}
		// 用响应方私钥解密加密密钥密文，比对时间戳，取后32个字符反HEX，得对称密钥
		String merKey = MerchantKeyMap.getKey(merId); // 商户对称密钥
        if (merKey == null) return params;

		// 对称密钥解密“加密json1”，得到明文“请求业务json”
		String reqData = "";
		try {
			reqData = new String(DESCrypto.deCrypt(
					ByteArrayUtil.hexString2ByteArray(reqEncData), merKey));
		} catch (Exception e) {
			logger.error("解密业务参数失败", e);
			params.put("retCode", CrossBorderConstant.ERROR_0011);
			params.put("retMsg", CrossBorderConstant.ERROR_0011_MSG);
			return params;
		}
		params.put("retCode", CrossBorderConstant.SUCCESS);
		params.put("reqData", reqData);
		params.put("merKey", merKey);
		return params;
	}

	public static void main(String[] args) throws UnsupportedEncodingException, Exception {
		String enc="66D1926499EBA99FBECE7D25653A8E5C6D0787538332C3CA6AB350EFF73B4D0776083A83DD42E77580BD433AE69E1DD4935FE18405873F209B4AF9160C1F7CD66AE107F6A688AF8B2DEB8D6C7068BBF80A4C0FD1570286AB22CC609BF54DDF22FA53739BDC65A955F236E72B11139242A8C83FC18C0C36F2D4AC77C122979507CD8C54499D910FEDBBB372241B4FB4FFA015238E0BA7B00AE91276B6713F2AC8922623C5A4A75989939D0C0453F4CFE5708CE9661A8C0CB6261D4B4457330A6AC35FCC1EE9E88BCF17D670234705D5CFD79412FAA01C8235B998F7F1452504A9";
		String mecKey="7OA400AZ3SS6F19T5BFT7EZPRH8H7YTI";
		System.err.println(ByteArrayUtil.hexString2ByteArray(enc));
		System.err.println(DESCrypto.deCrypt(ByteArrayUtil.hexString2ByteArray(enc), mecKey));
	}
	

}
