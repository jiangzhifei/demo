package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.lakala.testmer.util.PaySign;
import com.lakala.testmer.util.PropertiesConfigUtil;

/**
 * 商户注册接口
 * 
 * @author Hippo
 * @date 2014-3-29
 */
public class MerRegServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(MerRegServlet.class);
	private static final long serialVersionUID = 1L;

	public MerRegServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		try {
			PaySign ps = new PaySign();
			// 获取请求参数
			String org_code = request.getParameter("org_code"); // 机构代码
			String log_type = request.getParameter("log_type"); // 用户名类型
			String login_name = request.getParameter("login_name"); // 登录名
			String login_pwd = request.getParameter("login_pwd"); // 登录密码
			login_pwd = PaySign.EncoderByMd5(login_pwd);
			String pay_pwd = request.getParameter("pay_pwd"); // 支付密码
			pay_pwd = PaySign.EncoderByMd5(pay_pwd);
			String real_name = request.getParameter("real_name"); // 请求流水号
			String version = request.getParameter("version"); // 版本号
			String idcard_no = request.getParameter("idcard_no"); // 身份证号
			String user_category = request.getParameter("user_category"); // 用户身份类型
			// -----------------------------------------------------
			String business_type = request.getParameter("business_type"); // 业务合作类型ID
			String shop_name = request.getParameter("shop_name"); // 店名
			String shop_address = request.getParameter("shop_address"); // 地址
			String merchant_name = request.getParameter("merchant_name"); // 商户名称
			String prov_code = request.getParameter("prov_code"); // 商户所属省份代码
			String area_code = request.getParameter("area_code"); // 商户所属城市代码
			//
			String merchant_adress = request.getParameter("merchant_adress"); // 商户地址
			String register_number = request.getParameter("register_number"); // 营业执照注册号
			String tax_number = request.getParameter("tax_number"); // 税务登记证号
			String business_scope = request.getParameter("business_scope"); // 经营范围
			// ----------
			String merchant_intro = request.getParameter("merchant_intro"); // 商户简介
			String organ_code = request.getParameter("organ_code"); // 组织机构代码
			String open_acount_number = request.getParameter("open_acount_number"); // 开户许可证号
			String cred_img_a = request.getParameter("cred_img_a"); // 身份证正面
			String cred_img_b = request.getParameter("cred_img_b"); // 身份证背面
			String cred_img_c = request.getParameter("cred_img_c"); // 身份证与本人合照
			String head_img = request.getParameter("head_img"); // 门头照
			String business_license = request.getParameter("business_license"); // 营业执照
			String tax_card = request.getParameter("tax_card"); // 税务登记证

			String organ_card = request.getParameter("organ_card"); // 组织机构代码证
			String open_account_license = request.getParameter("open_account_license"); // 开户许可证
			String bank_id = request.getParameter("bank_id"); // 开户行ID
			String bank_user_name = request.getParameter("bank_user_name"); // 开户名
			String card_no = request.getParameter("card_no"); // 卡号
			String bank_prov_code = request.getParameter("bank_prov_code"); // 银行所属省份代码
			String bank_city_code = request.getParameter("bank_city_code"); // 银行所属市代码
			String card_branch_bank = request.getParameter("card_branch_bank"); // 支行代码
			String user_type = request.getParameter("user_type"); // 用户类型
			String terminal_id = request.getParameter("terminal_id"); // 设备号
			String ext1 = request.getParameter("ext1"); // 扩展参数一
			String ext2 = request.getParameter("ext2"); // 扩展参数二
			// /记录日志
			String parameter = "org_code=" + org_code + "&version=" + version + "&log_type=" + log_type + "&login_name=" + login_name + "&login_pwd="
					+ login_pwd + "&pay_pwd=" + pay_pwd + "&real_name=" + real_name + "&idcard_no=" + idcard_no + "&user_category=" + user_category
					+ "&business_type=" + business_type + "&shop_name=" + shop_name + "&shop_address=" + shop_address + "&merchant_name=" + merchant_name
					+ "&prov_code=" + prov_code + "&area_code=" + area_code + "&merchant_adress=" + merchant_adress + "&register_number=" + register_number
					+ "&tax_number=" + tax_number + "&business_scope=" + business_scope + "&merchant_intro=" + merchant_intro + "&organ_code=" + organ_code
					+ "&open_acount_number=" + open_acount_number + "&cred_img_a=" + cred_img_a + "&cred_img_b=" + cred_img_b + "&cred_img_c=" + cred_img_c
					+ "&head_img=" + head_img + "&business_license=" + business_license + "&tax_card=" + tax_card + "&organ_card=" + organ_card
					+ "&open_account_license=" + open_account_license + "&bank_id=" + bank_id + "&bank_user_name=" + bank_user_name + "&card_no=" + card_no
					+ "&bank_prov_code=" + bank_prov_code + "&bank_city_code=" + bank_city_code + "&card_branch_bank=" + card_branch_bank + "&user_type="
					+ user_type + "&terminal_id=" + terminal_id + "&ext1=" + ext1 + "&ext2=" + ext2;
			logger.info("用户注册开始，参数[" + parameter+"]");
			// 参数校验，必检项目
			if (StringUtils.isEmpty(org_code)) {
				logger.error("0001机构代码为空");
			}
			if (StringUtils.isEmpty(log_type)) {
				logger.error("0003用户名类型为空");
			}
			if (StringUtils.isEmpty(login_name)) {
				logger.error("0004登录名为空");
			}
			// plat_id
			if (StringUtils.isEmpty(real_name)) {
				logger.error("0005姓名为空");
			}
			if (StringUtils.isEmpty(idcard_no)) {
				logger.error("0006身份证号为空");
			}
			if (StringUtils.isEmpty(user_category)) {
				logger.error("0007用户身份类型为空");
			}
			if (StringUtils.isEmpty(user_type)) {
				logger.error("0008用户类型为空");
			}
			if (StringUtils.isEmpty(pay_pwd)) {
				logger.error("0010支付密码为空那个");
			}
			// 拼接字符串
			parameter = parameter.replaceAll("null", "");
			
			// 签名处理
			String servletContextPath = request.getServletContext().getRealPath("/");
			String proFile = servletContextPath + "/WEB-INF/classes/site.properties";
			Properties prop = new Properties();
			prop = PropertiesConfigUtil.load(proFile);
			String merKey = prop.getProperty("org_" + org_code);
			String signData = ps.sign(parameter, merKey);

			// 接口调用
			Map<String, String> map = new HashMap<String, String>();
			map.put("org_code", org_code);
			map.put("version", version);
			map.put("log_type", log_type);
			map.put("login_name", login_name);
			map.put("login_pwd", login_pwd);
			map.put("pay_pwd", pay_pwd);
			map.put("real_name", real_name);
			map.put("idcard_no", idcard_no);
			map.put("user_category", user_category);
			map.put("business_type", business_type);
			map.put("shop_name", shop_name);
			map.put("shop_address", shop_address);
			map.put("merchant_name", merchant_name);
			map.put("prov_code", prov_code);
			map.put("area_code", area_code);
			map.put("merchant_adress", merchant_adress);
			map.put("register_number", register_number);
			map.put("tax_number", tax_number);
			map.put("business_scope", business_scope);
			map.put("merchant_intro", merchant_intro);
			map.put("organ_code", organ_code);
			map.put("open_acount_number", open_acount_number);
			map.put("cred_img_a", cred_img_a);
			map.put("cred_img_b", cred_img_b);
			map.put("cred_img_c", cred_img_c);
			map.put("head_img", head_img);
			map.put("business_license", business_license);
			map.put("tax_card", tax_card);
			map.put("organ_card", organ_card);
			map.put("open_account_license", open_account_license);
			map.put("bank_id", bank_id);
			map.put("bank_user_name", bank_user_name);
			map.put("card_no", card_no);
			map.put("bank_prov_code", bank_prov_code);
			map.put("bank_city_code", bank_city_code);
			map.put("card_branch_bank", card_branch_bank);
			map.put("user_type", user_type);
			map.put("terminal_id", terminal_id);
			map.put("ext1", ext1);
			map.put("ext2", ext2);
			map.put("signData", signData);
			request.setAttribute("merRegMap", map);
			// 响应结果
			request.getRequestDispatcher("sendMerReg.jsp").forward(request, response);
			logger.error("[商户订单查询请求]查询处理结束");
			return;
		} catch (Exception e) {
			logger.error("[获取商户订单查询请求处理异常]", e);
		} finally {
		}
		logger.info("[商户订单查询请求]请求处理结束");
	}

}
