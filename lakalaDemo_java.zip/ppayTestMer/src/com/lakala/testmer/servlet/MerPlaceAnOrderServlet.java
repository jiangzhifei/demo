package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.aps.commons.StringUtils;
import com.lakala.testmer.util.DESCrypto;
import com.lakala.testmer.util.DigestUtil;
import com.lakala.testmer.util.HttpHelper;
import com.lakala.testmer.util.RSAUtil;
import com.lakala.testmer.util.Tools;

/**
 * 跨境支付商户下单
 * @author will
 *
 */
public class MerPlaceAnOrderServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3932202618859442112L;
	private static final Logger logger = Logger.getLogger(MerPlaceAnOrderServlet.class);
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		logger.info("下单");
		String ts = request.getParameter("ts");
		String ver = request.getParameter("ver");//协议版本号
		String merId = request.getParameter("merId");//商户号
		String reqType = request.getParameter("reqType");//请求业务类型
		String payTypeId = request.getParameter("payTypeId");
		
		String merOrderId = request.getParameter("merOrderId");
//		String custId = request.getParameter("custId");
		String currency = request.getParameter("currency");
		String orderAmount = request.getParameter("orderAmount");
		String payeeAmount = request.getParameter("payeeAmount");
		String clientName = request.getParameter("clientName");
		String certType = request.getParameter("certType");
		String clientId = request.getParameter("clientId");
		String cardNo = request.getParameter("cardNo");
		String dateOfExpire = request.getParameter("dateOfExpire");
		String orderEffTime = request.getParameter("orderEffTime");
		String cvv = request.getParameter("cvv");
		String mobile = request.getParameter("mobile");
		String busiRange = request.getParameter("busiRange");
		String orderSummary = request.getParameter("orderSummary");
		String orderTime = request.getParameter("orderTime");
		String timeZone = request.getParameter("timeZone");
		String pageUrl = request.getParameter("pageUrl");
		String bgUrl = request.getParameter("bgUrl");
		String ext1 = request.getParameter("ext1");//扩展字段1
		String ext2 = request.getParameter("ext2");//扩展字段2
		
		String cuId = request.getParameter("cuId");						// 海关id
		String bizTypeCode = request.getParameter("bizTypeCode");		// 业务类型
		String goodsFee = request.getParameter("goodsFee");				// 商品货款金额
		String taxFee = request.getParameter("taxFee");					// 税款金额
		String isMergeSign = request.getParameter("isMergeSign");					// 税款金额
		String buyForexKind = request.getParameter("buyForexKind");					// 购汇种类
		
//		clientName = "霍亮";
		//提供给商户的平台公钥
		String pingtaiPublicKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "pingtaiPublicKey");
		//商户的私钥
		String merPrivateKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), merId);
		
		//1.商户随机3DES对称密钥
		String merDesStr = Tools.getRandomString(32);
		//2.时间戳
		String dateStr = ts;//"2014110719160012";
		
		String encKey = "";
		String encKeyStr = dateStr+merDesStr;
		logger.info("时间戳拼接对称密钥encKeyStr==="+encKeyStr);
		//3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
		try {
			encKey = ByteArrayUtil.byteArray2HexString(RSAUtil.encryptByPublicKey(encKeyStr.getBytes(), pingtaiPublicKey));
		} catch (Exception e) {
			logger.error("加密对称密钥失败", e);
		}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("merOrderId", merOrderId);
//		params.put("custId", custId);
		params.put("currency", currency);
		params.put("orderAmount", orderAmount);
		params.put("payeeAmount", payeeAmount);
		params.put("clientName", clientName);
		params.put("certType", certType);
		params.put("clientId", clientId);
		params.put("cardNo", cardNo);
		params.put("dateOfExpire", dateOfExpire);
		params.put("cvv", cvv);
		params.put("mobile", mobile);
		params.put("busiCode", busiRange);
		params.put("orderSummary", orderSummary);
		params.put("orderTime", orderTime);
		params.put("timeZone", timeZone);
		params.put("pageUrl", pageUrl);
		params.put("bgUrl", bgUrl);
		params.put("ext1", ext1);
		params.put("ext2", ext2);
		params.put("orderEffTime", orderEffTime);
		params.put("isMergeSign", isMergeSign);
		
		//扩展字段
		Map<String, String> extensionMap = new HashMap<String, String>();
		extensionMap.put("cuId", cuId);
		extensionMap.put("bizTypeCode", bizTypeCode);
		extensionMap.put("goodsFee", goodsFee);
		extensionMap.put("taxFee", taxFee);
		extensionMap.put("buyForexKind", buyForexKind);
		
		
		//代收白名单模式
		String isDirectPay = request.getParameter("isDirectPay");//是否启用白名单
		String merClientId = request.getParameter("merClientId");//商户客户会员号
		String signDealNumber = request.getParameter("signDealNumber");//签约协议号
		params.put("isDirectPay", isDirectPay);
		params.put("merClientId", merClientId);
		params.put("signDealNumber", signDealNumber);
		
		
		params.put("extension", extensionMap);
		
//		params.put("payTypeId", payTypeId);
		String json = JsonUtil.map2Json(params);
		//加密请求业务json
		String json1 = ByteArrayUtil.byteArray2HexString(DESCrypto.enCrypto(json.getBytes(), merDesStr));
		
		//拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
		// 拼接
		String macStr = merId + ver + dateStr+reqType+json1 + StringUtils.trimToEmpty(payTypeId);
		// SHA1
		macStr = DigestUtil.Encrypt(macStr, "SHA-1");
		String mac = "";
		try {
			mac = ByteArrayUtil.byteArray2HexString(RSAUtil.encryptByPrivateKey(macStr.getBytes(), merPrivateKey));
		} catch (Exception e) {
			logger.error("生成MAC失败", e);
		}
		
		String url = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "ppayGateUrl");
		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put("ver", ver);
		reqMap.put("merId", merId);
		reqMap.put("ts", dateStr);
		reqMap.put("reqType", reqType);
		reqMap.put("payTypeId", payTypeId);
		reqMap.put("encKey", encKey);
		reqMap.put("encData", json1);
		reqMap.put("mac", mac);
//		logger.info("req:" + JsonUtil.map2Json(reqMap));
		
		String result = HttpHelper.doHttp(url, HttpHelper.POST, "UTF-8", JsonUtil.map2Json(reqMap), "5500000");
		logger.info("res:" + result);
		if (result == null) {
			logger.error("支付平台返回null");
			return ;
		}
		Map<String, String> retMap = JsonUtil.jsonToMap(result);
		String retVer = retMap.get("ver");
		String retMerId = retMap.get("merId");
		String retTs = retMap.get("ts");
		String retReqType = retMap.get("reqType");
		String retPayTypeId = retMap.get("payTypeId");
		String retEncData = retMap.get("encData");
		String retMac = retMap.get("mac");
		String retCode = retMap.get("retCode");
		String retMsg = retMap.get("retMsg");
		if (retCode == null || !retCode.equals("0000")) {
			logger.error("下单失败 ret=" + retMap.toString());
			request.setAttribute("retMsg",retMsg);
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("placeOrderRet.jsp").forward(request, response);
			return;
		}
		
		String retMacStr = DigestUtil.Encrypt(retCode+retMsg+retMerId + retVer+retTs+retReqType+retEncData + StringUtils.trimToEmpty(payTypeId), "SHA-1");
		logger.info("SHA-1加密响应返回的mac"+retMacStr);
		String reqMacStr = "";
		try {
			reqMacStr = new String(RSAUtil.decryptByPublicKey(ByteArrayUtil.hexString2ByteArray(retMac), pingtaiPublicKey));
		} catch (Exception e) {
			logger.error("解密MAC失败", e);
			request.setAttribute("retMsg","解密MAC失败");
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("placeOrderRet.jsp").forward(request, response);
			return;
		}
		
		String resData = "";
		try {
			logger.info(retEncData);
			byte[] byte_retEncData = ByteArrayUtil.hexString2ByteArray(retEncData);

			byte[] tmp1 = DESCrypto.deCrypt(byte_retEncData, merDesStr);
			resData = new String(tmp1);
			logger.info("res:" + result);
			logger.info("业务响应结果：" + resData);
			
		} catch (Exception e) {
			logger.error("", e);
			request.setAttribute("retMsg", retMsg);
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("placeOrderRet.jsp").forward(request, response);
			return;
		}
		Map<String,String> ywMap = JsonUtil.jsonToMap(resData);
		request.setAttribute("retMsg", retMsg);
		request.setAttribute("retCode", retCode);
		request.setAttribute("merOrderId", ywMap.get("merOrderId"));
		request.setAttribute("orderTime", ywMap.get("orderTime"));
		request.setAttribute("currency", ywMap.get("currency"));
		request.setAttribute("cnyAmount", ywMap.get("cnyAmount"));
		request.setAttribute("exchangeRate", ywMap.get("exchangeRate"));
		request.setAttribute("transactionId", ywMap.get("transactionId"));
		request.setAttribute("smsStatus", ywMap.get("smsStatus"));
		request.setAttribute("ext1", ywMap.get("ext1"));
		request.setAttribute("ext2", ywMap.get("ext2"));
		
		request.getRequestDispatcher("placeOrderRet.jsp").forward(request, response);
		
	}
	
}
