package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lakala.aps.commons.StringUtil;
import org.apache.log4j.Logger;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.testmer.util.DESCrypto;
import com.lakala.testmer.util.DigestUtil;
import com.lakala.testmer.util.HttpHelper;
import com.lakala.testmer.util.RSAUtil;
import com.lakala.testmer.util.Tools;

/**
 * 跨境支付商户退款
 * @author 
 *
 */
public class MerRefundServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1607461936018177867L;
	private static final Logger logger = Logger.getLogger(MerRefundServlet.class);

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.info("商户退款");
		String ts = request.getParameter("ts");
		String ver = request.getParameter("ver");//协议版本号
		String merId = request.getParameter("merId");//商户号
		String reqType = request.getParameter("reqType");//请求业务类型
		
		String seqId = request.getParameter("seqId");  //退款订单号
		String merOrderId = request.getParameter("merOrderId");//原订单号
		String retTime = request.getParameter("retTime");  //退款提交时间
		String retAmt = request.getParameter("retAmt");    //退款金额
		String retCny = request.getParameter("retCny");    //退款币种
		String ext1 = request.getParameter("ext1");//扩展字段1
		String ext2 = request.getParameter("ext2");//扩展字段2
		
		//提供给商户的平台公钥
		String pingtaiPublicKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "pingtaiPublicKey");
		//商户的私钥
		String merPrivateKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), merId);
		
		//1.商户随机3DES对称密钥
		String merDesStr = Tools.getRandomString(32);
		//2.时间戳
		String dateStr = ts;//"2014110719160012";
		
		String encKey = "";
		String encKeyStr = dateStr+merDesStr;
		logger.info("时间戳拼接对称密钥encKeyStr==="+encKeyStr);
		//3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
		try {
			encKey = ByteArrayUtil.byteArray2HexString(RSAUtil.encryptByPublicKey(encKeyStr.getBytes(), pingtaiPublicKey));
		} catch (Exception e) {
			logger.error("加密对称密钥失败", e);
		}
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("seqId", seqId);
		params.put("merOrderId", merOrderId);
		params.put("retTime", retTime);
		params.put("retAmt", retAmt);
		params.put("retCny", retCny);
		params.put("ext1", ext1);
		params.put("ext2", ext2);
		String json = JsonUtil.map2Json(params);
		//加密请求业务json
		String json1 = ByteArrayUtil.byteArray2HexString(DESCrypto.enCrypto(json.getBytes(), merDesStr));
		
		//拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
		// 拼接
		String macStr = merId + ver +dateStr+reqType+json1;
		// SHA1
		macStr = DigestUtil.Encrypt(macStr, "SHA-1");
		String mac = "";
		try {
			mac = ByteArrayUtil.byteArray2HexString(RSAUtil.encryptByPrivateKey(macStr.getBytes(), merPrivateKey));
		} catch (Exception e) {
			logger.error("生成MAC失败", e);
		}
		String product = request.getParameter("product");

		String url = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "ppayGateUrl" + (product != null && product.length() > 0 ? "." + product : ""));
		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put("ver", ver);
		reqMap.put("merId", merId);
		reqMap.put("ts", dateStr);
		reqMap.put("reqType", reqType);
		reqMap.put("encKey", encKey);
		reqMap.put("encData", json1);
		reqMap.put("mac", mac);
		logger.info("req:" + JsonUtil.map2Json(reqMap));

		String result = HttpHelper.doHttp(url, HttpHelper.POST, "UTF-8",
				//product != null && product.length() > 0 ? HttpHelper.getNvPairs(reqMap,"UTF-8"):
						JsonUtil.map2Json(reqMap),
				"5500000");
		logger.info("res:" + result);
		if (result == null) {
			logger.error("支付平台返回null");
			return ;
		}
		Map<String, String> retMap = JsonUtil.jsonToMap(result);
		String retVer = retMap.get("ver");
		String retMerId = retMap.get("merId");
		String retTs = retMap.get("ts");
		String retReqType = retMap.get("reqType");
		String retEncData = retMap.get("encData");
		String retMac = retMap.get("mac");
		String retCode = retMap.get("retCode");
		String retMsg = retMap.get("retMsg");
		if (retCode == null || !retCode.equals("0000")) {
			logger.error("下单失败 ret=" + retMap.toString());
			request.setAttribute("retMsg",retMsg);
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("placeOrderRet.jsp").forward(request, response);
			return;
		}
		
		String retMacStr = DigestUtil.Encrypt(retCode+retMsg+ver+retTs+retReqType+retEncData, "SHA-1");
		logger.info("SHA-1加密响应返回的mac"+retMacStr);
		String reqMacStr = "";
		try {
			reqMacStr = new String(RSAUtil.decryptByPublicKey(ByteArrayUtil.hexString2ByteArray(retMac), pingtaiPublicKey));
		} catch (Exception e) {
			logger.error("解密MAC失败", e);
			request.setAttribute("retMsg","解密MAC失败");
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("placeOrderRet.jsp").forward(request, response);
			return;
		}
		
		String resData = "";
		try {
			logger.info(retEncData);
			byte[] byte_retEncData = ByteArrayUtil.hexString2ByteArray(retEncData);

			byte[] tmp1 = DESCrypto.deCrypt(byte_retEncData, merDesStr);
			resData = new String(tmp1);
			logger.info("res:" + result);
			logger.info("业务响应结果：" + resData);
			
		} catch (Exception e) {
			logger.error("", e);
			request.setAttribute("retMsg", retMsg);
			request.setAttribute("retCode", retCode);
			request.getRequestDispatcher("placeOrderRet.jsp").forward(request, response);
			return;
		}
		Map<String,String> ywMap = JsonUtil.jsonToMap(resData);
		request.setAttribute("retMsg", retMsg);
		request.setAttribute("retCode", retCode);
		request.setAttribute("merOrderId", ywMap.get("merOrderId"));
		request.setAttribute("orderTime", ywMap.get("orderTime"));
		request.setAttribute("transactionId", ywMap.get("transactionId"));
		request.setAttribute("seqId", ywMap.get("seqId"));
		request.setAttribute("retStatu", ywMap.get("retStatu"));
		request.setAttribute("ext1", ywMap.get("ext1"));
		request.setAttribute("ext2", ywMap.get("ext2"));
		
		request.getRequestDispatcher("merRefundRet.jsp").forward(request, response);
	}

}
