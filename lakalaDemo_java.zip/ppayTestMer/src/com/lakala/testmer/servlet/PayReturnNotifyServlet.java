package com.lakala.testmer.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sound.midi.SysexMessage;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.aps.commons.StringUtil;
import com.lakala.testmer.util.CrossBorderConstant;
import com.lakala.testmer.util.DESCrypto;
import com.lakala.testmer.util.DigestUtil;
import com.lakala.testmer.util.RSAUtil;
import com.lakala.testmer.util.Tools;
/**
 * Servlet implementation class MerSignServlet
 */
/**
 * 支付结果通知
 * @author buybal-hl
 *
 */
public class PayReturnNotifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(PayReturnNotifyServlet.class);

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		logger.info("testMer------处理支付结果通知doPost");
		PrintWriter writer = null;
		Map<String, String> retMap = new HashMap<String, String>();
		try {
			response.setContentType("application/json; charset=utf-8");
			writer = response.getWriter();
			
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			logger.info("平台支付结果请求开始...");
			String reqJson = null;
			retMap.put("retCode", CrossBorderConstant.ERROR_0001);
			retMap.put("retMsg", CrossBorderConstant.ERROR_0001_MSG);

			// 1. 接收平台请求
			String submitMehtod = request.getMethod();
			if (submitMehtod.equals("GET")) {// GET
				reqJson = request.getQueryString();
			} else {// POST
				reqJson = getRequestPostBytes(request);
			}

			if (StringUtil.isEmpty(reqJson)) {
				retMap.put("retCode", CrossBorderConstant.ERROR_0002);
				retMap.put("retMsg", CrossBorderConstant.ERROR_0002_MSG);
				logger.error(retMap.toString());
				writer.append(JsonUtil.map2Json(retMap));
				writer.flush();
				
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
			// URL编码转换
			reqJson = URLDecoder.decode(reqJson, "utf-8");
			logger.info("平台支付结果，请求参数：" + reqJson);

			@SuppressWarnings("rawtypes")
			Map jsonMap = JsonUtil.jsonToMap(reqJson);

			// 2. 获取商户私钥，平台公钥，验证签名，解密
			if (jsonMap == null || !jsonMap.containsKey("reqType")|| !jsonMap.containsKey("merId")
					|| !jsonMap.containsKey("ts")|| !jsonMap.containsKey("ver")
					|| !jsonMap.containsKey("encKey")|| !jsonMap.containsKey("encData")
					|| !jsonMap.containsKey("mac")) {
				// 参数上送错误
				logger.error(retMap.toString());
				retMap.put("retCode", CrossBorderConstant.ERROR_0002);
				retMap.put("retMsg", CrossBorderConstant.ERROR_0002_MSG);
				writer.append(JsonUtil.map2Json(retMap));
				writer.flush();
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
			String merId = (String) jsonMap.get("merId");
			if (StringUtil.isEmpty(merId)) {
				logger.error("商户号为null");
				retMap.put("retCode", CrossBorderConstant.ERROR_0002);
				retMap.put("retMsg", CrossBorderConstant.ERROR_0002_MSG);
				writer.append(JsonUtil.map2Json(retMap));
				writer.flush();
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
//			TmerinfoService merInfoService = new TmerinfoService();
//			Tmerinfo merinfo = merInfoService.selectByPrimaryKey(merId);
//			if (merinfo == null || merinfo.getSTATE() != 1) {
//				logger.error("获取商户信息失败：merId=" + merId);
//				retMap.put("retCode", CrossBorderConstant.ERROR_0014);
//				retMap.put("retMsg", CrossBorderConstant.ERROR_0014_MSG);
//				writer.append(JsonUtil.map2Json(retMap));
//				writer.flush();
//				request.getRequestDispatcher("error.jsp").forward(request, response);
//			}

			// 获取商户私钥
//			String merPrivateKey = merinfo.getRSA_PRI_KEY();
			String merPrivateKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), merId);
			
			//获取平台公钥
//			DataDicService dicService = new DataDicService();
//			String platPublicKey = dicService.getDataDic("PlatformKey", "publicKey").getDIC_NAME();
			String platPublicKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "pingtaiPublicKey");
			
			if (StringUtil.isEmpty(platPublicKey)) {
				logger.error("获取平台公钥失败");
				retMap.put("retCode", CrossBorderConstant.ERROR_0001);
				retMap.put("retMsg", CrossBorderConstant.ERROR_0001_MSG);
				writer.append(JsonUtil.map2Json(retMap));
				writer.flush();
				return;
			}
			// 解密、验证mac
			retMap = decryptReqData(jsonMap, platPublicKey, merPrivateKey);
			if (!CrossBorderConstant.SUCCESS.equals(retMap.get("retCode"))) {
				logger.error("解析请求：" + retMap.toString());
				writer.append(JsonUtil.map2Json(retMap));
				writer.flush();
				return ;
			}
			logger.info("解密验签成功");
			String reqData = retMap.get("reqData");
			Map<String, String> params = JsonUtil.jsonToMap(reqData);
			Map<String,String> map = new HashMap<String,String>();
			map.put("merOrderId", params.get("merOrderId"));
			map.put("transactionId", params.get("transactionId"));
			
			String resData = JsonUtil.map2Json(map);
			logger.info("处理返回信息：" + resData);
			String merKey = retMap.get("merKey");

			// 5. 签名，加密
			Map<String, String> resMap = encryRetData(resData, jsonMap, merKey, merPrivateKey);
			logger.info("加密成功");
			logger.info("成功加密串"+resMap);
			// 6. 返回响应
			
			writer.append(JsonUtil.map2Json(resMap));
			writer.flush();
			return;
		} catch (Exception e) {
			logger.error("系统异常",e);
			writer.append(JsonUtil.map2Json(retMap));
			writer.flush();
			return;
		}
	
	}
	
	/**
	 * 在post请求中获取报文
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	private String getRequestPostBytes(HttpServletRequest request)
			throws IOException {
		int contentLength = request.getContentLength();
		if (contentLength < 0) {
			return null;
		}
		byte buffer[] = new byte[contentLength];
		for (int i = 0; i < contentLength;) {
			int readlen = request.getInputStream().read(buffer, i,
					contentLength - i);
			if (readlen == -1) {
				break;
			}
			i += readlen;
		}
		return new String(buffer, "utf-8");
	}

	/**
	 * 获取时间戳--非实际意义的时间戳
	 * 
	 * @return
	 */
	public String getTs() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String str = sdf.format(new Date());
		String s = System.currentTimeMillis() + "";
		return str + s.substring(7);
	}

	/**
	 * 数据加密(retCode和retMsg不进行加密)
	 * 
	 * @param resJsonData
	 *            业务参数
	 * @param reqMap
	 *            用户请求数据
	 * @param merDesStr
	 *            商户对称密钥
	 * @param merPrivateKey
	 *            商户私钥
	 * 
	 * @return
	 */
	private Map<String, String> encryRetData(String resJsonData, Map<String, String> reqMap, String merDesStr, String merPrivateKey) {
		String retCode = CrossBorderConstant.SUCCESS;
		String retMsg = CrossBorderConstant.SUCCESS_MSG;
		
		String ts = reqMap.get("ts");
		String ver = reqMap.get("ver"); 
		String merId = reqMap.get("merId"); 
		String reqType = reqMap.get("reqType");
		Map<String, String> jsonMap = new HashMap<String, String>();
		jsonMap.put("merId", merId);
		jsonMap.put("ver", ver);
		jsonMap.put("ts", ts);
		jsonMap.put("reqType", reqType);
		if (StringUtil.isEmpty(resJsonData) || StringUtil.isEmpty(ts)
				|| StringUtil.isEmpty(ver) || StringUtil.isEmpty(reqType)
				|| StringUtil.isEmpty(merDesStr)) {
			logger.error("签名加密参数为null：resJsonData=" + resJsonData + ",ts=" + ts
					+ ",ver=" + ver + ",merId=" + merId + ",merDesStr="
					+ merDesStr);
			jsonMap.put("retCode", CrossBorderConstant.ERROR_0002);
			jsonMap.put("retMsg", CrossBorderConstant.ERROR_0002_MSG);
			return jsonMap;
		}
		
		@SuppressWarnings("rawtypes")
		Map resMap_tmp = JsonUtil.jsonToMap(resJsonData);
		if (resMap_tmp != null && resMap_tmp.containsKey("retCode")) {
			retCode = (String) resMap_tmp.get("retCode");
			retMsg = (String) (resMap_tmp.get("retMsg") == null ? null : resMap_tmp.get("retMsg"));
			if (null == retCode || "".equals(retCode)) {
				retCode = CrossBorderConstant.SUCCESS;
				retMsg = CrossBorderConstant.SUCCESS_MSG;
			}
		}
		resMap_tmp.remove("retCode");
		resMap_tmp.remove("retMsg");
		resJsonData = JsonUtil.map2Json(resMap_tmp);
		
		// 1.使用用户上送的对称密钥加密响应业务JSON，生成加密JSON2
		String encData = ByteArrayUtil.byteArray2HexString(DESCrypto.enCrypto(
				resJsonData.getBytes(), merDesStr));

		// 2.拼接时间戳、业务类型、加密JSON2 做SHA1，响应方私钥加密，HEX，得MAC
		String mac_tmp = DigestUtil.Encrypt(ts + reqType + encData, "SHA-1");
		String mac = "";
		try {
			mac = ByteArrayUtil.byteArray2HexString(RSAUtil
					.encryptByPrivateKey(mac_tmp.getBytes(), merPrivateKey));
		} catch (Exception e) {
			logger.error("加密返回数据失败", e);
			jsonMap.put("retCode", CrossBorderConstant.ERROR_0012);
			jsonMap.put("retMsg", CrossBorderConstant.ERROR_0012_MSG);
			return jsonMap;
		}
		
		jsonMap.put("encData", encData);
		jsonMap.put("mac", mac);
		jsonMap.put("retCode", retCode);
		jsonMap.put("retMsg", retMsg);
		return jsonMap;
	}

	/**
	 * 解密请求数据
	 * 
	 * @param params
	 *            平台请求原始数据
	 * @param platPublicKey
	 *            平台公钥
	 * @param merPrivateKey
	 *            商户私钥
	 * @return
	 */
	private Map<String, String> decryptReqData(Map<String, String> params,
			String platPublicKey, String merPrivateKey) {
		String ts = (String) params.get("ts");
		String reqType = (String) params.get("reqType");
		String reqEncKey = (String) params.get("encKey");
		String reqEncData = (String) params.get("encData");
		String reqMac = (String) params.get("mac");

		params.remove("mac");
		params.remove("encData");
		params.remove("encKey");

		// 用请求方公钥验签（拼接时间戳、业务类型、“加密json1”做SHA1，用请求方公钥解密mac反hex的字节数组，比较是否一致）
		String reqmacStr = DigestUtil.Encrypt(ts + reqType + reqEncData,
				"SHA-1");
		String reqMacStr = "";
		try {
			reqMacStr = new String(RSAUtil.decryptByPublicKey(
					ByteArrayUtil.hexString2ByteArray(reqMac), platPublicKey));
		} catch (Exception e) {
			logger.error("解密mac失败", e);
			params.put("retCode", CrossBorderConstant.ERROR_0016);
			params.put("retMsg", CrossBorderConstant.ERROR_0016_MSG);
			return params;
		}
		// mac校验
		if (!reqmacStr.equals(reqMacStr)) {
			logger.error("mac校验失败");
			params.put("retCode", CrossBorderConstant.ERROR_0015);
			params.put("retMsg", CrossBorderConstant.ERROR_0015_MSG);
			return params;
		}
		// 用响应方私钥解密加密密钥密文，比对时间戳，取后32个字符反HEX，得对称密钥
		String merKey = ""; // 商户对称密钥
		try {
			merKey = new String(RSAUtil.decryptByPrivateKey(
					ByteArrayUtil.hexString2ByteArray(reqEncKey),
					merPrivateKey));
		} catch (Exception e) {
			logger.error("解密商户对称密钥失败", e);
			params.put("retCode", CrossBorderConstant.ERROR_0017);
			params.put("retMsg", CrossBorderConstant.ERROR_0017_MSG);
			return params;
		}
		merKey = merKey.substring(merKey.length() - 32, merKey.length());
		// 对称密钥解密“加密json1”，得到明文“请求业务json”
		String reqData = "";
		try {
			reqData = new String(DESCrypto.deCrypt(
					ByteArrayUtil.hexString2ByteArray(reqEncData), merKey));
		} catch (Exception e) {
			logger.error("解密业务参数失败", e);
			params.put("retCode", CrossBorderConstant.ERROR_0011);
			params.put("retMsg", CrossBorderConstant.ERROR_0011_MSG);
			return params;
		}
		params.put("retCode", CrossBorderConstant.SUCCESS);
		params.put("reqData", reqData);
		params.put("merKey", merKey);
		return params;
	}
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PayReturnNotifyServlet() {
		super();
	}
	
	public static void main(String[] args) throws Exception {
		String encData = "1D09FFCE346BFF3967466761BE05E9784A605A0E30767908800737906613ED277B5DF296327EBBC8C001216330A082EC9933D57D2F460772226B2F1BF0ACDA046CC8DB3F7F4D7F0FF1E13CA103CFC23063C2B16DF254D6BC321D119DF67E91D0E960CDE4401525122C5815A5D4CFD5EAA29478C5B26BB0E5563EC376E1F552AD95C8A12FB0AA613C3B08A05DFD275C7648A77D423576F2A9AABF2492D2ABD0E96B6FF6AAC2A75A9F4AC70521F621B5F82B0B2C870E31B0C3F8C912EADB37D7AFD1F522FC2A2D38999CBCED91969EA5392AF5224944C3B6C9E3F88B90B4E4FB7E3EBA10B796A1A85A";
		String encKey="6ED32FBFBB60E385686A4E5B35F6457BDFD78AB60027B5F509FE083DBDFDDC6146F6C1FAE3168F967DAC827792BED0B6B99E8F9B4682EC49446221AC1DFD56D15E2A71EF4A010F23FE76CD41F9FC6874D5DC308476B5D1DAA95B6E6E31A9064CAAE37E1E65403DC5584F2DB08DB03FC08D97C63210CA053216AF7F7A99375520";
		String pri="MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAM+DQ7is9AkvU76OonisGMVU1EC4OYFKiKL2lh89AFp6xwJVjSKuRZagvJ9NPrlOO+c+k7H4h83MFOUHXeoIQWbtqWBESh5QeMWAU0eJcnYsr9HT5VaBd7n4QMV9usUI+eYsobc5woMZCzM/RU5/pVVMzW3noKmBpEybX/5PN3ZNAgMBAAECgYBwyQNxyG8K3vJBS/z6YW9FMYn7cyWuI/iHukZ1zA35H2oy1pTTGK0x5UMfwjgpN2BPmy9jN5V4QUfKA2sD3GDOuZee2RxsmsdgkZSnkv9VA+eL+03tL2yRIzAzqzhfeuh2xnwETXu7EhQNz41exU8Wom2tCEnUCr7BhalLlkod8QJBAPaYIkxlhovHW8kEetQF1XjlGpcrg0CW5dHSN581olNBTNzyzpk84HTUZhwme5zIlvecmPPaBbqyFZfwO1mlKr8CQQDXbYUHInIr+/1bvKpxlk/lwGzCeeLpTK/QhgVKyMnpqz9slWOoQUTS9uVCbsih9wT79H5vizcp2PjqO7Ctt93zAkEAiIGJIw9knsYaSjnfoLUmCgmRYbOlscCWskMTpV+0XzAb04fZ1Dw96I6Xg+fNr+neoG2gwgSj/UiN6ZED2ckz0wJBAIc4BzfjNybElNLwKUwCvUPI9HtdZkBqEjEg7lFylspE4xqU6mjCDyEcN+rq/qQrGMXNQU9iYs2xkwvzS4K+1mECQQDXdvp/bslihScm2Zs1v9LmqR69+DZ63U7p+bk2yh0d3XpnNRtUK7m6DwM1uxNi7GXDcJL005Ryodenv2KlJDL6";
		String pub="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDPg0O4rPQJL1O+jqJ4rBjFVNRAuDmBSoii9pYfPQBaescCVY0irkWWoLyfTT65TjvnPpOx+IfNzBTlB13qCEFm7algREoeUHjFgFNHiXJ2LK/R0+VWgXe5+EDFfbrFCPnmLKG3OcKDGQszP0VOf6VVTM1t56CpgaRMm1/+Tzd2TQIDAQAB";
		String merKey = new String(RSAUtil.decryptByPrivateKey(
				ByteArrayUtil.hexString2ByteArray(encKey),
				pri));
		merKey = merKey.substring(merKey.length() - 32, merKey.length());
		System.err.println(merKey);
		// 对称密钥解密“加密json1”，得到明文“请求业务json”
		String reqData = new String(DESCrypto.deCrypt(
					ByteArrayUtil.hexString2ByteArray(encData), merKey));
		System.err.println(reqData);
	}


}
