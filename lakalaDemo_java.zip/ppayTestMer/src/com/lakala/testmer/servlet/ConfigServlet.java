package com.lakala.testmer.servlet;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lakala.testmer.util.PropertiesConfigUtil;

/**
 * 设置商户号和商户接口密钥
 */
public class ConfigServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfigServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cmd = request.getParameter("cmd");
		String key = request.getParameter("key");
		String value = request.getParameter("value");
		
		String servletContextPath = request.getServletContext().getRealPath("/");
		String proFile = servletContextPath+"/WEB-INF/classes/site.properties";
		Properties prop = PropertiesConfigUtil.load(proFile);
		if (cmd!=null) {
			if ("set".equalsIgnoreCase(cmd)) {
				prop.setProperty(key, value);
			}
			if ("del".equalsIgnoreCase(cmd)) {
				prop.remove(key);
			}
		}
		PropertiesConfigUtil.save(proFile, prop);
		//
		request.setAttribute("TESTMER_PROPERTIES", prop);
		request.getRequestDispatcher("/config.jsp").forward(request, response);
	}

}
