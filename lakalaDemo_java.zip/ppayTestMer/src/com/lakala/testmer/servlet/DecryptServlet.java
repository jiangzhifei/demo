package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.JsonUtil;
import com.lakala.testmer.util.DESCrypto;
import com.lakala.testmer.util.DigestUtil;
import com.lakala.testmer.util.RSAUtil;

/**
 * Servlet implementation class MerSignServlet
 */
public class DecryptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(DecryptServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DecryptServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ver = request.getParameter("ver");//协议版本号
		String ts = request.getParameter("ts");//时间戳
		
		String merId = request.getParameter("merId");//商户号
		String reqType = request.getParameter("reqType");//请求业务类型
		String encKey = request.getParameter("encKey");//加密密钥
		String encData = request.getParameter("encData");//加密json
		String mac = request.getParameter("mac");//mac
		//平台私钥
		String pingtaiPrivateKey = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAM+DQ7is9AkvU76OonisGMVU1EC4OYFKiKL2lh89AFp6xwJVjSKuRZagvJ9NPrlOO+c+k7H4h83MFOUHXeoIQWbtqWBESh5QeMWAU0eJcnYsr9HT5VaBd7n4QMV9usUI+eYsobc5woMZCzM/RU5/pVVMzW3noKmBpEybX/5PN3ZNAgMBAAECgYBwyQNxyG8K3vJBS/z6YW9FMYn7cyWuI/iHukZ1zA35H2oy1pTTGK0x5UMfwjgpN2BPmy9jN5V4QUfKA2sD3GDOuZee2RxsmsdgkZSnkv9VA+eL+03tL2yRIzAzqzhfeuh2xnwETXu7EhQNz41exU8Wom2tCEnUCr7BhalLlkod8QJBAPaYIkxlhovHW8kEetQF1XjlGpcrg0CW5dHSN581olNBTNzyzpk84HTUZhwme5zIlvecmPPaBbqyFZfwO1mlKr8CQQDXbYUHInIr+/1bvKpxlk/lwGzCeeLpTK/QhgVKyMnpqz9slWOoQUTS9uVCbsih9wT79H5vizcp2PjqO7Ctt93zAkEAiIGJIw9knsYaSjnfoLUmCgmRYbOlscCWskMTpV+0XzAb04fZ1Dw96I6Xg+fNr+neoG2gwgSj/UiN6ZED2ckz0wJBAIc4BzfjNybElNLwKUwCvUPI9HtdZkBqEjEg7lFylspE4xqU6mjCDyEcN+rq/qQrGMXNQU9iYs2xkwvzS4K+1mECQQDXdvp/bslihScm2Zs1v9LmqR69+DZ63U7p+bk2yh0d3XpnNRtUK7m6DwM1uxNi7GXDcJL005Ryodenv2KlJDL6";
		//商户公钥
		String merPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCQuQpNqag1vYn7KJReFFM6FcYg8JtvIdu1yqhWQXR2lxMIF7COMmIeOGKPF6BM0QRaYysw4vJ9j3+6+cBLbdd9ey7tgfWBBZcMVF99kI1WgSTyH0aO2HDhU1boUe3+f9YQgrl0s3DazhAs0OT+UyjdY/nzo4QyeUo96ml+T3WQMQIDAQAB";
		
		//7.用请求方公钥验签（拼接时间戳、业务类型、“加密json1”做SHA1，用请求方公钥解密mac反hex的字节数组，比较是否一致）
		String macStr = DigestUtil.Encrypt(ts+reqType+encData, "SHA-1");
		System.out.println("SHA-1加密以后的mac原文---"+macStr);
		String reqMacStr = "";
		try {
			reqMacStr = new String(RSAUtil.decryptByPublicKey(ByteArrayUtil.hexString2ByteArray(mac), merPublicKey));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("商户公钥解密以后的请求SHA-1mac原文---"+reqMacStr);
		//mac校验
		if(!macStr.equals(reqMacStr)) {
			//mac校验失败
			return ;
		}
		//8校验时间戳（a.时间是否在当前允许范围，b.时间戳入库检查是否主键冲突）
		
		//9.用响应方私钥解密加密密钥密文，比对时间戳，取后32个字符反HEX，得对称密钥
		String merKey = "";
		try {
			merKey = new String(RSAUtil.decryptByPrivateKey(ByteArrayUtil.hexString2ByteArray(encKey), pingtaiPrivateKey));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("使用平台公钥解密以后的请求方的加密密钥---"+merKey);
		merKey = merKey.substring(merKey.length()-32,merKey.length());
		System.out.println("请求方生成的3DES密钥明文"+merKey);
//		merKey = new String(ByteArrayUtil.hexString2ByteArray(merKey.substring(merKey.length()-32,merKey.length())));
		//10.对称密钥解密“加密json1”，得到明文“请求业务json”
		String reqData = "";
		try {
			reqData = new String(DESCrypto.deCrypt(ByteArrayUtil.hexString2ByteArray(encData), merKey));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("请求方业务参数原文"+reqData);
		Map map = JsonUtil.jsonToMap(reqData);
		String queryDate = (String) map.get("queryDate");
		String currency = (String) map.get("currency");
		String ext1 = (String)map.get("ext1");
		String ext2 = (String)map.get("ext2");
		//11.根据业务类型反序列化“请求业务json”，得到请求业务对象
		
		//12.业务处理，生成响应业务json
		
		//13.用对称密钥3DES加密
		
//		//1.商户随机3DES对称密钥
//		String merDesStr = Tools.getRandomString(32);
//		System.out.println("商户随机3DES对称密钥merDesStr="+merDesStr);
//		//2.时间戳
//		String dateStr = StringUtil.getRandomUUID();
//		System.out.println("时间戳dateStr"+dateStr);
//		//3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
//		String encKey = ByteArrayUtil.byteArray2HexString(MacUtil.des3Encrypt(ByteArrayUtil.hexString2ByteArray(pingtaiPublicKey), ByteArrayUtil.hexString2ByteArray(dateStr+merDesStr)));
//		//4.用对称密钥3DES加密“请求业务json”，生成“加密json1”
//		Map map = new HashMap();
//		map.put("queryDate", queryDate);
//		map.put("currency", currency);
//		map.put("ext1", ext1);
//		map.put("ext2", ext2);
//		String json = JsonUtil.map2Json(map);
//		//加密请求业务json
//		String json1 = ByteArrayUtil.byteArray2HexString(MacUtil.des3Encrypt(ByteArrayUtil.hexString2ByteArray(merDesStr), ByteArrayUtil.hexString2ByteArray(json)));
//		
//		//拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
//		//拼接
//		String macStr = dateStr+reqType+json1;
//		//SHA1
//		String mac = ByteArrayUtil.byteArray2HexString(MacUtil.des3Encrypt(ByteArrayUtil.hexString2ByteArray(merPrivateKey), ByteArrayUtil.hexString2ByteArray(DigestUtil.Encrypt("macStr", "SHA-1"))));
//		
//		
//		request.setAttribute("ver", ver);
//		request.setAttribute("merId", merId);
//		request.setAttribute("ts", dateStr);
//		request.setAttribute("reqType", reqType);
//		request.setAttribute("encKey", encKey);
//		request.setAttribute("encData", json1);
//		request.setAttribute("mac", mac);
		request.setAttribute("ver", ver);
		request.setAttribute("merId", merId);
		request.setAttribute("queryDate", queryDate);
		request.setAttribute("currency", currency);
		request.setAttribute("ext1", ext1);
		request.setAttribute("ext2", ext2);
		request.getRequestDispatcher("exchangeRateToPay2.jsp").forward(request, response);
	}

}
