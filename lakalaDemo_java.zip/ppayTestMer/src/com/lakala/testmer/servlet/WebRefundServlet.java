package com.lakala.testmer.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lakala.pay.service.DovePayService;
import com.lakala.pay.service.DovePayServiceServiceLocator;
import com.lakala.testmer.util.EncException;
import com.lakala.testmer.util.PayEncrypt;
import com.lakala.testmer.util.PaySign;

/**
 * Servlet implementation class WebRefundServlet
 */
public class WebRefundServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WebRefundServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = request.getParameter("url");
		String transactionid = request.getParameter("transactionid");
		String pid = request.getParameter("pid");
		String seqid = request.getParameter("seqid");
		String returnallamount = request.getParameter("returnallamount");
		String returntime = request.getParameter("returntime");
		String ext1 = request.getParameter("ext1");
		String ext2 = request.getParameter("ext2");
		String returndetail = request.getParameter("returndetail");
		//对分账数据进行加密
		String merKey = "GheuVsd21ppay5J52DwfjTay";
		PayEncrypt pe=new PayEncrypt();
		try {
			returndetail = pe.encryptMode(merKey,returndetail);
			//System.out.println("--------------**********sharingData:"+sharingData);
			//System.out.println("sharingData in MerSignServlet:"+sharingData);
		} catch (EncException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuffer paramStr = new StringBuffer();
			paramStr.append("transactionid="+transactionid+"&");
			paramStr.append("pid="+pid+"&");
			paramStr.append("seqid="+seqid+"&");
			paramStr.append("returnallamount="+returnallamount+"&");
			paramStr.append("returntime="+returntime+"&");
			paramStr.append("ext1="+ext1+"&");
			paramStr.append("ext2="+ext2+"&");
			paramStr.append("returndetail="+returndetail);
		System.out.println("testServlet-------------"+paramStr.toString());
		//签名
		PaySign ps = new PaySign();
		try {
			String signmsg = ps.sign(paramStr.toString(), merKey);
			System.out.println("signmsg = "+signmsg);
			paramStr.append("&signmsg=").append(signmsg);
			DovePayServiceServiceLocator dpsl=new DovePayServiceServiceLocator();
			DovePayService dps=dpsl.getDovePayService();
			String returnStr=dps.refundDeal(paramStr.toString());
			System.out.println("------refundDeal-----"+returnStr);
			if(returnStr!=null){
				String signSrc=returnStr.substring(0, returnStr.indexOf("&signmsg"));
				String sign=returnStr.substring(returnStr.indexOf("&signmsg=")+"&signmsg=".length());
			    boolean bool=  ps.verify(signSrc, sign, merKey);
				String[] resArr = returnStr.split("&");
				for(int i=0;i<resArr.length;i++){
					String[] kvArr = resArr[i].split("=");
					if(kvArr[0].equals("transactionid")){
						response.getOutputStream().write(("商户交易号:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("pid")){
						response.getOutputStream().write(("商户标识:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("seqid")){
						response.getOutputStream().write(("退款流水号:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("returnallamount")){
						response.getOutputStream().write(("退款总金额:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("returnfee")){
						response.getOutputStream().write(("退款手续费:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("ext1")){
						response.getOutputStream().write(("扩展字段1:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("ext2")){
						response.getOutputStream().write(("扩展字段2:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("result")){
						response.getOutputStream().write(("结果:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("errcode")){
						response.getOutputStream().write(("错误代码:"+kvArr[1]+"---"+CodeUtil.errCode(kvArr[1])+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("returndata")&&kvArr.length>1){
						response.getOutputStream().write(("退款明细:"+kvArr[1]+"<br>").getBytes()); 
					}
					if(kvArr[0].equals("signmsg")){
						
						response.getOutputStream().write(("签名:"+kvArr[1]+"<br>").getBytes()); 
						if(bool){
							response.getOutputStream().write("签名验证成功".getBytes());
							}else{
								response.getOutputStream().write("签名验证失败".getBytes());
							}
				
					}
				}
			}
			response.getOutputStream().flush();   
			response.getOutputStream().close();

		}catch(Exception e){
		   e.printStackTrace();
		}	
		
	}

}
