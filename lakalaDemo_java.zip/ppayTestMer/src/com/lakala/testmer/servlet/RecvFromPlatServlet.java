package com.lakala.testmer.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class RecvFromPlatServlet
 */
public class RecvFromPlatServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(RecvFromPlatServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecvFromPlatServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.error("-----------------------recv from plat--------------------transactionid = "+request.getParameter("transactionid") + " orderamount = "+request.getParameter("orderamount")+" dealid = "+request.getParameter("dealid")+" payamount = "+request.getParameter("payamount"+" fee = "+request.getParameter("fee")+" payResult = "+request.getParameter("payResult")+" sharingResult = "+request.getParameter("sharingResult")));
	}

}
