package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.aps.commons.StringUtils;
import com.lakala.pay.service.MerInterfaceService;
import com.lakala.testmer.util.DESCrypto;
import com.lakala.testmer.util.DigestUtil;
import com.lakala.testmer.util.HttpHelper;
import com.lakala.testmer.util.RSAUtil;
import com.lakala.testmer.util.Tools;
/**
 * Servlet implementation class MerSignServlet
 */
/**
 * 模拟商户支付
 * @author buybal-hl
 *
 */
public class PayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(PayServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PayServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ver = request.getParameter("ver");//协议版本号
		String merId = request.getParameter("merId");//商户号
		String reqType = request.getParameter("reqType");//请求业务类型
		String payTypeId = request.getParameter("payTypeId");
		String ts = request.getParameter("ts");
		
		String merOrderId = request.getParameter("merOrderId");
		String currency = request.getParameter("currency");
		String orderAmount = request.getParameter("orderAmount");
		String payeeAmount = request.getParameter("payeeAmount");
		String msgCode = request.getParameter("msgCode");
		String transactionId = request.getParameter("transactionId");
		String ext1 = request.getParameter("ext1");//扩展字段1
		String ext2 = request.getParameter("ext2");//扩展字段2
		
		//2.时间戳
//		String dateStr = MerInterfaceService.getTs();
		logger.info("商户生产时间戳dateStr==="+ts);
		//3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
		String encKey = MerInterfaceService.getMerEncKey();
		logger.info("时间戳拼接对称密钥hexencKey==="+encKey);
		//4.用对称密钥3DES加密“请求业务json”，生成“加密json1”
		Map map = new HashMap();
		map.put("currency",currency);
		map.put("merOrderId",merOrderId);
		map.put("orderAmount",orderAmount);
		map.put("payeeAmount",payeeAmount);
		map.put("transactionId",transactionId);
		map.put("msgCode",msgCode);
		map.put("ext1", ext1);
		map.put("ext2", ext2);
		String json = JsonUtil.map2Json(map);
		logger.info("业务参数原文json==="+json);
		String json1 = MerInterfaceService.getJson1(json);
		logger.info("使用对称密钥加密以后的json1==="+json1);
		//拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
		String macStr1 = merId + ver + ts + reqType + json1 + StringUtils.trimToEmpty(payTypeId);
		String macStr = MerInterfaceService.getMacStr(macStr1);
		String mac = MerInterfaceService.getMac(macStr,merId);
		logger.info("商户私钥加密以后的mac==="+mac);
		
		String url = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "ppayGateUrl");
		Map reqMap = new HashMap();
		reqMap.put("ver", ver);
		reqMap.put("merId", merId);
		reqMap.put("ts", ts);
		reqMap.put("reqType", reqType);
		reqMap.put("payTypeId", payTypeId);
		reqMap.put("encKey", encKey);
		reqMap.put("encData", json1);
		reqMap.put("mac", mac);
		
		String result = HttpHelper.doHttp(url, HttpHelper.POST, "UTF-8", JsonUtil.map2Json(reqMap), "6000000");
		
		Map<String, String> retMap = JsonUtil.jsonToMap(result);
		
		String retVer = retMap.get("ver");
		String retMerId = retMap.get("merId");
		String retTs = retMap.get("ts");
		String retReqType = retMap.get("reqType");
		String retEncData = retMap.get("encData");
		String retMac = retMap.get("mac");
		String retCode = retMap.get("retCode");
		String retMsg = retMap.get("retMsg");
		
		request.setAttribute("retMsg", retMsg);
		request.setAttribute("retCode", retCode);
		if(!retCode.equals("0000")) {
			request.getRequestDispatcher("error.jsp").forward(request, response);
			return ;
		}
		
		String macStr2 = retCode + retMsg + merId + ver + retTs + retReqType + retEncData + StringUtils.trimToEmpty(payTypeId);
		String retMacStr = MerInterfaceService.getMacStr(macStr2);
		logger.info("SHA-1加密响应返回的mac:"+retMacStr);
		String reqMacStr = "";
		try {
			reqMacStr = MerInterfaceService.getReqMacStr(retMac);
			logger.info("取请求的Mac: "+reqMacStr);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(!retMacStr.equals(reqMacStr)) {
			request.setAttribute("retMsg", "MAC校验失败");
			request.getRequestDispatcher("error.jsp").forward(request, response);
			return ;
		}
		String reqData = "";
		try {
			reqData = MerInterfaceService.getReqData(retEncData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//支付返回信息
		Map<String, String> resultMap = JsonUtil.jsonToMap(reqData);
		
		request.setAttribute("orderTime", resultMap.get("orderTime"));
		request.setAttribute("merOrderId", resultMap.get("merOrderId"));
		request.setAttribute("dealTime", resultMap.get("dealTime"));
		request.setAttribute("orderFee", resultMap.get("orderFee"));
		request.setAttribute("cnyAmount", resultMap.get("cnyAmount"));
		request.setAttribute("exchangeRate", resultMap.get("exchangeRate"));
		request.setAttribute("transactionId", resultMap.get("transactionId"));
		request.setAttribute("payResult", resultMap.get("payResult"));
		request.setAttribute("ext1", resultMap.get("ext1"));
		request.setAttribute("ext2", resultMap.get("ext2"));
		request.setAttribute("retVer", retVer);
		request.setAttribute("retMerId", retMerId);
		request.setAttribute("", resultMap.get(""));
		request.setAttribute("", resultMap.get(""));
		
		request.getRequestDispatcher("payReturn.jsp").forward(request, response);
	}

}
