package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.testmer.util.PaySign;
import com.lakala.testmer.util.PropertiesConfigUtil;

public class OrgSetServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(OrgSetServlet.class);
	private static final long serialVersionUID = 1L;
    public OrgSetServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		try{
			//获取请求参数
			String orgCode = request.getParameter("orgCode"); //机构号
			String startDate = request.getParameter("startDate"); //开始时间
			String endDate = request.getParameter("endDate"); //结束时间
			String notifyAddr = request.getParameter("notifyAddr"); //通知商户地址
			String version = request.getParameter("version"); //版本号
			String privData = request.getParameter("privData"); //版本号
			logger.info("[商户对账请求]请求处理开始,orgCode="+orgCode+",startDate="+startDate+",endDate="+endDate+",notifyAddr="+notifyAddr+",version="+version);

			//签名处理
			String servletContextPath = request.getServletContext().getRealPath("/");
			String proFile = servletContextPath+"/WEB-INF/classes/site.properties";
			Properties prop = new Properties();
			prop = PropertiesConfigUtil.load(proFile);
			String orgKey=prop.getProperty("org_"+orgCode);
				
			String minData = appendSignData( orgCode, startDate, endDate, notifyAddr, version); //组建前面串明文
			PaySign ps = new PaySign();
			String signData = ps.sign(minData, orgKey);

			Map<String,String> map = new HashMap<String,String>();
			map.put("orgCode", orgCode);
			map.put("startDate",startDate);
			map.put("endDate", endDate);
			map.put("notifyAddr", notifyAddr);
			map.put("version", version);
			map.put("privData", privData);
			map.put("signData", signData);
			request.setAttribute("orgSetMap", map);
			//响应结果
			request.getRequestDispatcher("sendOrgSet.jsp").forward(request, response);
		}catch(Exception e){
			logger.error("[获取商户对账请求处理异常]",e);
		}finally{
			
		}
		logger.info("[商户对账请求]请求处理结束");
	}
	
	private String appendSignData(String orgCode,String startDate,String endDate,String notifyAddr,String version){
		StringBuffer sb = new StringBuffer();
		sb.append("orgCode=").append(orgCode).append("&");
		sb.append("startDate=").append(startDate).append("&");
		sb.append("endDate=").append(endDate).append("&");
		sb.append("notifyAddr=").append(notifyAddr).append("&");
		sb.append("version=").append(version);
		return sb.toString();
	}
}
