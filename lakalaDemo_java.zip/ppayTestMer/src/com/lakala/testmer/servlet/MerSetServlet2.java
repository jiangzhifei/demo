package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.pay.service.MerInterfaceService;
import com.lakala.testmer.util.HttpHelper;
import com.lakala.testmer.util.Tools;
/**
 * Servlet implementation class MerSignServlet
 */
public class MerSetServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(MerSetServlet2.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MerSetServlet2() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ver = request.getParameter("ver");//协议版本号
		String merId = request.getParameter("merId");//商户号
		String reqType = request.getParameter("reqType");//请求业务类型
		String startDate = request.getParameter("startDate");//对账开始日期
		String endDate = request.getParameter("endDate");//对账结束日期
		String notifyAddr = request.getParameter("notifyAddr");//通知下载地址
		String ext1 = request.getParameter("ext1");//扩展字段1
		String ext2 = request.getParameter("ext2");//扩展字段2
		
		//2.时间戳
		String dateStr = MerInterfaceService.getTs();
		logger.info("商户生产时间戳dateStr==="+dateStr);
		//3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
		String encKey = MerInterfaceService.getMerEncKey();
		logger.info("时间戳拼接对称密钥hexencKey==="+encKey);
		//4.用对称密钥3DES加密“请求业务json”，生成“加密json1”
		Map map = new HashMap();
		map.put("startDate", startDate);
		map.put("endDate", endDate);
		map.put("notifyAddr", notifyAddr);
		map.put("ext1", ext1);
		map.put("ext2", ext2);
		String json = JsonUtil.map2Json(map);
		logger.info("业务参数原文json==="+json);
		String json1 = MerInterfaceService.getJson1(json);
		logger.info("使用对称密钥加密以后的json1==="+json1);
		//拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
		String macStr1 = merId + ver + dateStr + reqType + json1;
		String macStr = MerInterfaceService.getMacStr(macStr1);
		String mac = MerInterfaceService.getMac(macStr,merId);
		logger.info("商户私钥加密以后的mac==="+mac);
		String product = request.getParameter("product");

		String url = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "ppayGateUrl" + (product != null && product.length() > 0 ? "." + product : ""));
		Map reqMap = new HashMap();
		reqMap.put("ver", ver);
		reqMap.put("merId", merId);
		reqMap.put("ts", dateStr);
		reqMap.put("reqType", reqType);
		reqMap.put("encKey", encKey);
		reqMap.put("encData", json1);
		reqMap.put("mac", mac);
		
		String result = HttpHelper.doHttp(url, HttpHelper.POST, "UTF-8", JsonUtil.map2Json(reqMap), "60000");
		
		Map<String, String> retMap = JsonUtil.jsonToMap(result);
		
		String retVer = retMap.get("ver");
		String retMerId = retMap.get("merId");
		String retTs = retMap.get("ts");
		String retReqType = retMap.get("reqType");
		String retEncData = retMap.get("encData");
		String retMac = retMap.get("mac");
		String retCode = retMap.get("retCode");
		String retMsg = retMap.get("retMsg");
		
		
		request.setAttribute("retMsg", retMsg);
		if(!retCode.equals("0000")) {
			request.getRequestDispatcher("checkFileResult.jsp").forward(request, response);
			return ;
		}
		String macStr2 = retCode + retMsg + merId + ver + retTs + retReqType + retEncData;
		String retMacStr = MerInterfaceService.getMacStr(macStr2);
		logger.info("SHA-1加密响应返回的mac"+retMacStr);
		String reqMacStr = "";
		try {
			reqMacStr = MerInterfaceService.getReqMacStr(retMac);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(!retMacStr.equals(reqMacStr)) {
			request.setAttribute("retMsg", "MAC校验失败");
			request.getRequestDispatcher("checkFileResult.jsp").forward(request, response);
			return ;
		}
		String reqData = "";
		try {
			reqData = MerInterfaceService.getReqData(retEncData);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher("checkFileResult.jsp").forward(request, response);
	}

}
