package com.lakala.testmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.JsonUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.aps.commons.StringUtils;
import com.lakala.pay.service.MerInterfaceService;
import com.lakala.testmer.util.HttpHelper;
import com.lakala.testmer.util.Tools;

/**
 * 商户订单查询接口
 * @author Hippo
 * @date 2013-4-22
 */
public class QueryOrderServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(QueryOrderServlet.class);
	private static final long serialVersionUID = 1L;
       
    
    public QueryOrderServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		try {
			// 获取请求参数
			String ver = request.getParameter("ver"); // 版本号
			String merId = request.getParameter("merId"); // 商户号
			String reqType = request.getParameter("reqType"); // 业务类型
			String merOrderId = request.getParameter("merOrderId"); // 商户订单号
			String transactionId = request.getParameter("transactionId"); //流水号
			String ext1 = request.getParameter("ext1");
			String ext2 = request.getParameter("ext2"); 
		
			//提供给商户的平台公钥
			String pingtaiPublicKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "pingtaiPublicKey");
			//商户的私钥
			String merPrivateKey = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "merPrivateKey");
			
			//1.商户随机3DES对称密钥
			String merDesStr = Tools.getRandomString(32);
			
			//2.时间戳
			String dateStr = MerInterfaceService.getTs();
			logger.info("商户生产时间戳dateStr==="+dateStr);
			//3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
			String encKey = MerInterfaceService.getMerEncKey();
			logger.info("时间戳拼接对称密钥hexencKey==="+encKey);
			//4.用对称密钥3DES加密“请求业务json”，生成“加密json1”
			Map map = new HashMap();
			map.put("merOrderId", merOrderId);
			map.put("transactionId", transactionId);
			map.put("ext1", ext1);
			map.put("ext2", ext2);
			String json = JsonUtil.map2Json(map);
			logger.info("业务参数原文json==="+json);
			String json1 = MerInterfaceService.getJson1(json);
			logger.info("使用对称密钥加密以后的json1==="+json1);
			//拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
			String macStr1 = merId+ver+dateStr+reqType+json1;
			String macStr = MerInterfaceService.getMacStr(macStr1);
			String mac = MerInterfaceService.getMac(macStr,merId);
			logger.info("商户私钥加密以后的mac==="+mac);
			
			String url = PropertiseUtil.getDataFromPropertiseFile(Tools.getRealPropertyFileName(request.getSession(),"site"), "ppayGateUrl");
			Map reqMap = new HashMap();
			reqMap.put("ver", ver);
			reqMap.put("merId", merId);
			reqMap.put("ts", dateStr);
			reqMap.put("reqType", reqType);
			reqMap.put("encKey", encKey);
			reqMap.put("encData", json1);
			reqMap.put("mac", mac);
			
			
			String result = HttpHelper.doHttp(url, HttpHelper.POST, "UTF-8", JsonUtil.map2Json(reqMap), "60000");
			
			Map<String, String> retMap = JsonUtil.jsonToMap(result);
			
			String retVer = retMap.get("ver");
			String retMerId = retMap.get("merId");
			String retTs = retMap.get("ts");
			String retReqType = retMap.get("reqType");
			String retEncData = retMap.get("encData");
			String retMac = retMap.get("mac");
			String retCode = retMap.get("retCode");
			String retMsg = retMap.get("retMsg");
			
			request.setAttribute("retMsg", retMsg);
			request.setAttribute("retCode", retCode);
			if(!retCode.equals("0000")) {
				request.getRequestDispatcher("sendQueryOrder.jsp").forward(request, response);
				return ;
			}
			
			String retMacStr1 = retCode + retMsg+merId+ver+retTs+retReqType+retEncData;
			String retMacStr = MerInterfaceService.getMacStr(retMacStr1);
			logger.info("SHA-1加密响应返回的mac"+retMacStr);
			String reqMacStr = "";
			try {
				reqMacStr = MerInterfaceService.getReqMacStr(retMac);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if(!retMacStr.equals(reqMacStr)) {
				request.setAttribute("retMsg", "MAC校验失败");
				request.getRequestDispatcher("sendQueryOrder.jsp").forward(request, response);
				return ;
			}
			String reqData = "";
			try {
				reqData = MerInterfaceService.getReqData(retEncData);
			} catch (Exception e) {
				e.printStackTrace();
			}
			Map<String, String> resultMap = JsonUtil.jsonToMap(reqData);
			
			String orderTime1 = resultMap.get("orderTime");//订单日期
			String merOrderId1 = resultMap.get("merOrderId");
			String transactionId1 = resultMap.get("transactionId");
			String currency=resultMap.get("currency");//订单币种
			String orderAmount=resultMap.get("orderAmount");//商户订单金额
			String orderFee=resultMap.get("orderFee");//手续费
			String dealTime=resultMap.get("dealTime");//交易成功时间
			String payResult = resultMap.get("payResult");
			String cnyAmount = resultMap.get("cnyAmount");
			String exchangeRate = resultMap.get("exchangeRate");
			String ext11 = resultMap.get("ext1");
			String ext21 = resultMap.get("ext2");
			String payResultStr = "";
			if("10000101000000".equals(dealTime)){
				dealTime=null;
			}
			//0：未支付，1：已支付，2：失效；3：已冲正；4：已撤销；99：关闭
			if("0".equals(payResult)) {
				payResultStr = "未支付";
			}
			if("1".equals(payResult)) {
				payResultStr = "已支付";
			}
			if("2".equals(payResult)) {
				payResultStr = "订单已失效";
			}
			if("3".equals(payResult)) {
				payResultStr = "已冲正";
			}
			if("4".equals(payResult)) {
				payResultStr = "已撤销";
			}
			if("99".equals(payResult)) {
				payResultStr = "订单已关闭";
			}
			request.setAttribute("retCode", retCode);
			request.setAttribute("retMsg", retMsg);
			request.setAttribute("orderTime1", orderTime1);
			request.setAttribute("merOrderId1", merOrderId1);
			request.setAttribute("currency",currency);
			request.setAttribute("orderAmount",orderAmount);
			request.setAttribute("orderFee",orderFee);
			request.setAttribute("dealTime",dealTime);
			request.setAttribute("transactionId1", transactionId1);
			request.setAttribute("payResult", payResult);
			request.setAttribute("payResultStr", payResultStr);
			request.setAttribute("cnyAmount",cnyAmount );
			request.setAttribute("exchangeRate", exchangeRate);
			request.setAttribute("ext1", ext11);
			request.setAttribute("ext2", ext21);
			//响应结果
			request.getRequestDispatcher("sendQueryOrder.jsp").forward(request, response);
			logger.info("[商户订单查询请求]查询处理结束");
			return ;
		} catch (Exception e) {
			logger.error("[获取商户订单查询请求处理异常]", e);
		} finally {
		}
		logger.info("[商户订单查询请求]请求处理结束");
	}
	
}
