package com.lakala.testmer.servlet;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lakala.testmer.util.EncException;
import com.lakala.testmer.util.PaySign;

/**
 * Servlet implementation class CheckAccountsServlet
 */
public class CheckAccountsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CheckAccountsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getParameter("url");
		String pid = request.getParameter("pid");
		String reqdate = request.getParameter("reqdate");
		String rdpwd = request.getParameter("rdpwd");
		String merKey = "GheuVsd21ppay5J52DwfjTay";
		StringBuffer paramStr = new StringBuffer();
		Map<String,String> paramMap = new HashMap<String,String>();
		paramMap.put("pid", pid);
		paramMap.put("reqdate", reqdate);
		paramMap.put("rdpwd", rdpwd);
		if(pid!=null){
			paramStr.append("pid="+pid+"&");
		}
		if(reqdate!=null){
			paramStr.append("reqdate="+reqdate+"&");
		}
		if(rdpwd!=null){
			paramStr.append("rdpwd="+rdpwd+"&");
		}
		if(paramStr.indexOf("&")!=-1){
			paramStr.deleteCharAt(paramStr.lastIndexOf("&"));
		}
		System.out.println("checkAccountsServlet-------------"+paramStr.toString());
		//签名
		PaySign ps = new PaySign();
		try {
			String signmsg = ps.sign(paramStr.toString(), merKey);
			System.out.println("signmsg = "+signmsg);
			paramMap.put("signmsg", signmsg);
			/*HttpRequester hr = new HttpRequester();
			HttpRespons httpResponse = hr.sendPost(url, paramMap);
			response.getOutputStream().write(httpResponse.getContent().toString().getBytes()); 
			response.getOutputStream().flush();   
			response.getOutputStream().close();*/
			request.setAttribute("url", url);
			request.setAttribute("paramMap", paramMap);
			request.getRequestDispatcher("topay.jsp").forward(request, response);
		} catch (EncException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
