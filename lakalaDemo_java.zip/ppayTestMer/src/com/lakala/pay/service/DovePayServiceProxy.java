package com.lakala.pay.service;

public class DovePayServiceProxy implements com.lakala.pay.service.DovePayService {
  private String _endpoint = null;
  private com.lakala.pay.service.DovePayService ppayService = null;
  
  public DovePayServiceProxy() {
    _initDovePayServiceProxy();
  }
  
  public DovePayServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initDovePayServiceProxy();
  }
  
  private void _initDovePayServiceProxy() {
    try {
      ppayService = (new com.lakala.pay.service.DovePayServiceServiceLocator()).getDovePayService();
      if (ppayService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)ppayService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)ppayService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (ppayService != null)
      ((javax.xml.rpc.Stub)ppayService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.lakala.pay.service.DovePayService getDovePayService() {
    if (ppayService == null)
      _initDovePayServiceProxy();
    return ppayService;
  }
  
  public java.lang.String queryOrder(java.lang.String message) throws java.rmi.RemoteException{
    if (ppayService == null)
      _initDovePayServiceProxy();
    return ppayService.queryOrder(message);
  }
  
  public java.lang.String refundDeal(java.lang.String message) throws java.rmi.RemoteException{
    if (ppayService == null)
      _initDovePayServiceProxy();
    return ppayService.refundDeal(message);
  }
  
  public java.lang.String registMer(java.lang.String message) throws java.rmi.RemoteException{
    if (ppayService == null)
      _initDovePayServiceProxy();
    return ppayService.registMer(message);
  }
  
  public java.lang.String queryRemain(java.lang.String message) throws java.rmi.RemoteException{
    if (ppayService == null)
      _initDovePayServiceProxy();
    return ppayService.queryRemain(message);
  }
  
  public java.lang.String prePaid(java.lang.String message) throws java.rmi.RemoteException{
    if (ppayService == null)
      _initDovePayServiceProxy();
    return ppayService.prePaid(message);
  }
  
  
}