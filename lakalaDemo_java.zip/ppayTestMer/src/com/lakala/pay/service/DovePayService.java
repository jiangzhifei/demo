/**
 * DovePayService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.lakala.pay.service;

public interface DovePayService extends java.rmi.Remote {
    public java.lang.String queryOrder(java.lang.String message) throws java.rmi.RemoteException;
    public java.lang.String refundDeal(java.lang.String message) throws java.rmi.RemoteException;
    public java.lang.String registMer(java.lang.String message) throws java.rmi.RemoteException;
    public java.lang.String queryRemain(java.lang.String message) throws java.rmi.RemoteException;
    public java.lang.String prePaid(java.lang.String message) throws java.rmi.RemoteException;
}
