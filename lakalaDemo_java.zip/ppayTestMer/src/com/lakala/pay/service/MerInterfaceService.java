package com.lakala.pay.service;

import java.util.Date;

import org.apache.log4j.Logger;

import com.lakala.aps.commons.ByteArrayUtil;
import com.lakala.aps.commons.DateUtil;
import com.lakala.aps.commons.PropertiseUtil;
import com.lakala.testmer.util.DESCrypto;
import com.lakala.testmer.util.DigestUtil;
import com.lakala.testmer.util.RSAUtil;
import com.lakala.testmer.util.Tools;

public class MerInterfaceService {

	private static final Logger logger = Logger.getLogger(MerInterfaceService.class);

	// 提供给商户的平台公钥
	public static String pingtaiPublicKey = PropertiseUtil
			.getDataFromPropertiseFile("site", "pingtaiPublicKey");
	// 商户的私钥
//	public static String merPrivateKey = PropertiseUtil
//			.getDataFromPropertiseFile("site", "merPrivateKey");

	// 1.商户随机3DES对称密钥
	public static String merDesStr = Tools.getRandomString(32);

	// 2.时间戳
	public static String dateStr = "";

	/**
	 * 获取时间戳
	 * 
	 * @return
	 */
	public static String getTs() {
		dateStr = DateUtil.fomatDate(new Date(), "yyyyMMddHHmmssSSSSSS");
		return dateStr;
	}

	/**
	 * 获取商户3DES对称密钥密文
	 * 
	 * @return
	 */
	// 3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
	public static String getMerEncKey() {
		String encKey = "";
		String encKeyStr = dateStr + merDesStr;
		logger.info("时间戳拼接对称密钥encKeyStr===" + encKeyStr);
		// 3.时间戳拼接对称密钥的hex，用响应方公钥加密，生成加密密钥密文，hex编码
		// RSAUtil.encrypt(Base64.decodeBase64(pingtaiPublicKey),ByteArrayUtil.hexString2ByteArray(dateStr+merDesStr)));
		try {
			encKey = ByteArrayUtil
					.byteArray2HexString(RSAUtil.encryptByPublicKey(
							encKeyStr.getBytes(), pingtaiPublicKey));
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("时间戳拼接对称密钥hexencKey===" + encKey);
		return encKey;
	}

	/**
	 * 获取加密业务数据json1
	 * 
	 * @param json
	 * @return
	 */
	public static String getJson1(String json) {
		String json1 = ByteArrayUtil.byteArray2HexString(DESCrypto.enCrypto(
				json.getBytes(), merDesStr));
		logger.info("使用对称密钥加密以后的json1===" + json1);
		return json1;
	}

	/**
	 * 获取SHA1mac原文
	 * @param reqType
	 * @param json1
	 * @return
	 */
	public static String getMacStr(String macStr) {
		// 拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
		// 拼接
		// SHA1
		String mac = DigestUtil.Encrypt(macStr, "SHA-1");
		return mac;
	}

	/**
	 * 获取mac
	 * 
	 * @param reqType
	 * @param json1
	 * @return
	 */
	public static String getMac(String macStr,String merId) {
		String merPrivateKey = PropertiseUtil.getDataFromPropertiseFile("site", merId);
		// 拼接时间戳、业务类型、加密json1、做SHA1,请求方私钥加密，HEX，等MAC
		String mac = "";
		try {
			mac = ByteArrayUtil.byteArray2HexString(RSAUtil
					.encryptByPrivateKey(macStr.getBytes(), merPrivateKey));
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("商户私钥加密以后的mac===" + mac);
		return mac;
	}
	
	/**
	 * 解密响应mac，返回SHA-1mac原文
	 * @param retMac
	 * @return
	 */
	public static String getReqMacStr(String retMac){
		
		String reqMacStr = null;
		try {
			reqMacStr = new String(RSAUtil.decryptByPublicKey(ByteArrayUtil.hexString2ByteArray(retMac), pingtaiPublicKey));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return reqMacStr;
	}
	
	/**
	 * 解密响应业务数据
	 * @param retEncData
	 * @return
	 */
	public static String getReqData(String retEncData) {
		String reqData = "";
		try {
			reqData = new String(DESCrypto.deCrypt(ByteArrayUtil.hexString2ByteArray(retEncData), merDesStr));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return reqData;
	}

	public static void main(String[] args) {
		logger.info(getTs());
	}

}
