/**
 * DovePayServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.lakala.pay.service;

public class DovePayServiceServiceLocator extends org.apache.axis.client.Service implements com.lakala.pay.service.DovePayServiceService {

    public DovePayServiceServiceLocator() {
    }


    public DovePayServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public DovePayServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for DovePayService
    private java.lang.String DovePayService_address = "http://127.0.0.1:8888/ppayWebService/services/DovePayService";

    public java.lang.String getDovePayServiceAddress() {
        return DovePayService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String DovePayServiceWSDDServiceName = "DovePayService";

    public java.lang.String getDovePayServiceWSDDServiceName() {
        return DovePayServiceWSDDServiceName;
    }

    public void setDovePayServiceWSDDServiceName(java.lang.String name) {
        DovePayServiceWSDDServiceName = name;
    }

    public com.lakala.pay.service.DovePayService getDovePayService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(DovePayService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getDovePayService(endpoint);
    }

    public com.lakala.pay.service.DovePayService getDovePayService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.lakala.pay.service.DovePayServiceSoapBindingStub _stub = new com.lakala.pay.service.DovePayServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getDovePayServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setDovePayServiceEndpointAddress(java.lang.String address) {
        DovePayService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.lakala.pay.service.DovePayService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.lakala.pay.service.DovePayServiceSoapBindingStub _stub = new com.lakala.pay.service.DovePayServiceSoapBindingStub(new java.net.URL(DovePayService_address), this);
                _stub.setPortName(getDovePayServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("DovePayService".equals(inputPortName)) {
            return getDovePayService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://service.pay.buybal.com", "DovePayServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://service.pay.buybal.com", "DovePayService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("DovePayService".equals(portName)) {
            setDovePayServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
